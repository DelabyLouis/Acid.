<?php

return [
    'CAPTCHA_SECRET' => null,
    'ENCRYPTION_KEY' => null,
    'LDAP_PASS' => null,
];
