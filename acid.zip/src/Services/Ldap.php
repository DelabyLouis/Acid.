<?php

namespace App\Services;

use App\Entity\Direction;
use App\Entity\Utilisateur;
use Doctrine\ORM\EntityManagerInterface;

class Ldap
{
    /**
     * Constructeur : Init des variables et connexion au serveur AD
     */
    public function __construct(private readonly string $host, private readonly int $port, private readonly string $dn, private readonly string $baseDn,
                                private readonly string $ldapPass, private readonly EntityManagerInterface $em)
    {
        $this->rs = ['cn', 'sn', 'givenName', 'mail', 'employeeNumber', 'crndpcatttelephoneintl', 'title', 'jpegphoto',
            'crnpdcattfonctionlibelle', 'crnpdcattasciiprenom', 'uid', 'crnpdcattdirectionsigle'];

        $this->connect();
    }

    public function __destruct()
    {
        if ($this->ds) {
            ldap_close($this->ds);
        }
    }

    /**
     * Connexion au serveur AD
     */
    private function connect()
    {
        if ($this->port == 636) {
            $this->ds = ldap_connect('ldaps://' . $this->host, $this->port);
        } else {
            $this->ds = ldap_connect('ldap://' . $this->host, $this->port);
        }

        if ($this->ds) {
            ldap_set_option($this->ds, LDAP_OPT_PROTOCOL_VERSION, 3);
            ldap_set_option($this->ds, LDAP_OPT_REFERRALS, 0);
            ldap_bind($this->ds, $this->dn, $this->ldapPass);
        }
    }

    /**
     * Retourne les utilisateurs AD par le nom
     *
     * @param int $att 0: siège uniquement ; 1: ATT uniquement ; siège + ATT
     */
    public function findUsersByName(string $str, int $att = 0): array|string
    {
        $filtre = null;
        if ($this->ds && $str) {
            if ($att == 0) {
                $filtre = sprintf('(&(sn=*%s*)(objectClass=crnpdcobjagent)(|(businessCategory=PICARD)(businessCategory=INTERNE)))', $str);
            } else if ($att == 1) {
                $filtre = sprintf('(&(sn=*%s*)(objectClass=crnpdcobjagent)(|(businessCategory=PICARDTOS)(businessCategory=TOS)))', $str);
            } else if ($att == 2) {
                $filtre = sprintf('(&(sn=*%s*)(objectClass=crnpdcobjagent)(|(businessCategory=PICARD)(businessCategory=INTERNE)(businessCategory=PICARDTOS)(businessCategory=TOS)))', $str);
            }

            $srdir = ldap_search($this->ds, $this->baseDn, $filtre, $this->rs);

            return ldap_get_entries($this->ds, $srdir);
        }

        return ldap_error($this->ds);
    }

    /**
     * Retourne un utilisateur AD par son login
     *
     * @param string $login
     */
    public function findUserByLogin($login): array|string
    {
        if ($this->ds && $login) {
            //$filtre = "(&(extensionAttribute5=$login)(objectCategory=organizationalPerson)(extensionAttribute5=*))";
            $filtre = sprintf('(uid=%s)', $login);
            $srdir = ldap_search($this->ds, 'ou=usagers,' . $this->baseDn, $filtre, $this->rs);

            return ldap_get_entries($this->ds, $srdir);
        }

        return ldap_error($this->ds);
    }

    /**
     * Vérifie si un user a été retourné
     * @param $user
     */
    public function checkUser($user): bool
    {
        return $user != 'Success' && $user['count'] != 0;
    }

    /**
     * @param $user
     */
    public function getMatricule($user): ?string
    {
        if (isset($user[0]['employeenumber'][0])) {
            return $user[0]['employeenumber'][0];
        }
        if (isset($user['employeenumber'][0])) {
            return $user['employeenumber'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getCivilite($user): ?string
    {
        if (isset($user[0]['title'])) {
            return $user[0]['title'][0];
        } else if (isset($user['title'])) {
            return $user['title'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getNom($user): ?string
    {
        if (isset($user[0]['sn'])) {
            return $user[0]['sn'][0];
        } else if (isset($user['sn'])) {
            return $user['sn'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getPrenom($user): ?string
    {
        if (isset($user[0]['crnpdcattasciiprenom'])) {
            return ucfirst((string) $user[0]['crnpdcattasciiprenom'][0]);
        } else if (isset($user[0]['givenname'])) {
            return ucfirst((string) $user[0]['givenname'][0]);
        } else if (isset($user['crnpdcattasciiprenom'])) {
            return $user['crnpdcattasciiprenom'][0];
        } else if (isset($user['givenname'])) {
            return $user['givenname'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getEmail($user): ?string
    {
        if (isset($user[0]['mail'])) {
            // On prend le hautsdefrance.fr ou le premier à defaut
            foreach ($user[0]['mail'] as $email) {
                if (stristr((string) $email, '@hautsdefrance.fr')) {
                    return $email;
                }
            }

            return $user[0]['mail'][0];
        } else if (isset($user['mail'])) {
            return $user['mail'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getTelephone($user): ?string
    {
        if (isset($user[0]['crnpdcatttelephoneintl'])) {
            return $user[0]['crnpdcatttelephoneintl'][0];
        } else if (isset($user['crnpdcatttelephoneintl'])) {
            return $user['crnpdcatttelephoneintl'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getLogin($user): ?string
    {
        if (isset($user['uid'])) {
            return strtolower((string) $user['uid'][0]);
        } else if (isset($user['uid'])) {
            return $user['uid'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getFonction($user): ?string
    {
        if (isset($user[0]['crnpdcattfonctionlibelle'])) {
            return $user[0]['crnpdcattfonctionlibelle'][0];
        } else if (isset($user['crnpdcattfonctionlibelle'])) {
            return $user['crnpdcattfonctionlibelle'][0];
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getDirectionSigle($user): ?string
    {
        if (isset($user[0]['crnpdcattdirectionsigle'])) {
            return ucfirst((string) $user[0]['crnpdcattdirectionsigle'][0]);
        } else if (isset($user['crnpdcattdirectionsigle'])) {
            return ucfirst((string) $user['crnpdcattdirectionsigle'][0]);
        }

        return '';
    }

    /**
     * @param $user
     */
    public function getJpegPhoto($user): ?string
    {
        if (isset($user[0]['jpegphoto'])) {
            return base64_encode((string) $user[0]['jpegphoto'][0]);
        } else if (isset($user['jpegphoto'])) {
            return $user['jpegphoto'][0];
        }

        return '';
    }

    /**
     * Enregistrement d'un nouvel utilisateur
     */
    public function persistEntity(string $login): Utilisateur|bool
    {
        $user = $this->findUserByLogin($login);

        if (false === $this->checkUser($user)) {
            return false;
        }

        $utilisateur = new Utilisateur();
        $utilisateur->setCreatedAt(new \DateTime());
        $utilisateur->setUpdatedAt(new \DateTime());
        $utilisateur->setLogin($login);
        $utilisateur->setCivilite($this->getCivilite($user));
        $utilisateur->setNom($this->getNom($user));
        $utilisateur->setPrenom($this->getPrenom($user));
        $utilisateur->setEmail($this->getEmail($user));
        $utilisateur->setTelephone($this->getTelephone($user));
        $utilisateur->setMatricule($this->getMatricule($user));
        $utilisateur->setRole('Utilisateur');

        $direction_sigle = $this->getDirectionSigle($user);
        if ($direction_sigle) {
            $direction = $this->em->getRepository(Direction::class)->findOneBy(['sigle' => $direction_sigle]);
            if ($direction) {
                $utilisateur->setDirection($direction);
            }
        }

        $this->em->persist($utilisateur);
        $this->em->flush();

        return $utilisateur;
    }
}