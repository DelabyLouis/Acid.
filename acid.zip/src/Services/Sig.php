<?php

namespace App\Services;

use Symfony\Contracts\HttpClient\HttpClientInterface;

class Sig
{
    public function __construct(private readonly HttpClientInterface $client)
    {}

    /**
     * Requête API gouv pour récupération des adresses postales
     *
     * @return mixed
     * @throws \Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\DecodingExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface
     */
    public function findAdresses(string $q, string $code_insee = ''): string
    {
        if ($code_insee) {
            $url = "https://api-adresse.data.gouv.fr/search/?limit=99&citycode=$code_insee&q=$q";
        } else {
            $url = "https://api-adresse.data.gouv.fr/search/?limit=99&q=$q";
        }

        $response = $this->client->request('GET', $url);

        if ($response->getStatusCode() == 200) {
            return $this->formatAdresseResponse($response->toArray());
        }

        return '';
    }

    /**
     * Formatage de la réponse
     *
     * "properties" => [
     *   "label" => "69 Rue Rene Boileau 80090 Amiens"
     *   "score" => 0.88943181818182
     *   "housenumber" => "69"
     *   "id" => "80021_6770_00069"
     *   "name" => "69 Rue Rene Boileau"
     *   "postcode" => "80090"
     *   "citycode" => "80021"
     *   "x" => 651970.39
     *   "y" => 6975457.09
     *   "city" => "Amiens"
     *   "context" => "80, Somme, Hauts-de-France"
     *   "type" => "housenumber" // peut être "street" si pas de numéro saisie dans l'adresse
     *   "importance" => 0.78375
     *   "street" => "Rue Rene Boileau"
     * ]
     *
     * @param array $response
     * @return json
     */
    private function formatAdresseResponse(array $response): string
    {
        $adresses = [];

        if ($response['features']) {
            foreach ($response['features'] as $key => $item) {
                $adresses[$key] = $item['properties'];
                $adresses[$key]['longitude'] = $item['geometry']['coordinates'][0];
                $adresses[$key]['latitude'] = $item['geometry']['coordinates'][1];
            }
        }

        return json_encode($adresses, JSON_THROW_ON_ERROR);
    }

    /**
     * Calcul de distance entre deux points identifiés par leurs longitude et latitude
     * Doc : https://geoservices.ign.fr/documentation/services/api-et-services-ogc/itineraires/documentation-du-service-du-calcul
     *
     * @throws \Symfony\Contracts\HttpClient\Exception\ClientExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\DecodingExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\RedirectionExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\ServerExceptionInterface
     * @throws \Symfony\Contracts\HttpClient\Exception\TransportExceptionInterface
     */
    public function calculItineraire(float $startX, float $startY, float $endX, float $endY): string
    {
        $url = "https://wxs.ign.fr/calcul/geoportail/itineraire/rest/1.0.0/route?resource=bdtopo-osrm&start=$startX,$startY&end=$endX,$endY";
        $response = $this->client->request('GET', $url);

        if ($response->getStatusCode() == 200) {
            return json_encode($response->toArray(), JSON_THROW_ON_ERROR);
        }

        return '';
    }
}