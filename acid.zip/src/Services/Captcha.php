<?php

namespace App\Services;

use Symfony\Component\HttpClient\NativeHttpClient;
use Symfony\Contracts\HttpClient\HttpClientInterface;

class Captcha
{
    public function __construct(private readonly string $client_id, private readonly int $client_code, private readonly string $secret, private readonly string $url,
                                private readonly HttpClientInterface $client)
    {}

    /**
     * Retourne le challenge ID du captcha
     */
    public function create(): string|false
    {
        $response = $this->client->request('POST', $this->url . '/public/backend/api/v2/captcha', [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'auth_basic' => [$this->client_id, $this->secret],
            'query' => [
                "type" => "IMAGE",
                "locale" => "FR",
                'theme' => 'RANDOM',
            ],
        ]);

        $statusCode = $response->getStatusCode();

        if ($statusCode >= 200 && $statusCode < 400) {
            $responseData = json_decode($response->getContent(), null, 512, JSON_THROW_ON_ERROR);

            return $responseData->id;
        }

        return false;
    }

    public function getImageUrl(string $challeng_id): string
    {
        return $this->url . '/public/frontend/api/v2/captcha/' . $challeng_id . '.png';
    }

    /**
     * Vérifie si un captcha est valide
     */
    public function check(string $captcha_challenge_id, string $captcha_answer): bool
    {
        $response = $this->client->request('POST', $this->url . '/public/backend/api/v2/captcha/' . $captcha_challenge_id . '/checkAnswer', [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'auth_basic' => [$this->client_id, $this->secret],
            'json' => [
                'answer' => $captcha_answer,
            ],
        ]);

        $statusCode = $response->getStatusCode();

        if ($statusCode >= 200 && $statusCode < 400) {
            $responseData = json_decode($response->getContent(), null, 512, JSON_THROW_ON_ERROR);

            return $responseData->result == 'SUCCESS';
        }

        return false;
    }

    public function getStatistiques(string $start = null, string $end = null): \stdClass|false
    {
        $url = $this->url . '/public/backend/api/v2/captcha/stats';
        if ($start && $end) {
            $url .= '?startDate=' . $start . '&endDate=' . $end;
        }

        $response = $this->client->request('GET', $url, [
            'headers' => [
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'auth_basic' => [$this->client_id, $this->secret],
        ]);

        $statusCode = $response->getStatusCode();

        if ($statusCode >= 200 && $statusCode < 400) {
            return json_decode($response->getContent(), null, 512, JSON_THROW_ON_ERROR);
        }

        return false;
    }
}