<?php

namespace App\Form;

use App\Entity\RefReferent;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RefReferentType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('nom', TextType::class, [
                'label' => 'Nom* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('prenom', TextType::class, [
                'label' => 'Prénom* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('organismeBeneficiaire', TextType::class, [
                'label' => 'Organisme beneficiaire* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('adresse', TextType::class, [
                'label' => 'Adresse* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('cp', TextType::class, [
                'label' => 'Code Postal* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('ville', TextType::class, [
                'label' => 'Ville* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('mail', TextType::class, [
                'label' => 'Mail* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('actif', ChoiceType::class, [
                'label' => 'Actif*',
                'label_attr' => ['class' => 'radio-custom radio-inline'],
                'choices' => array(
                    'Oui' => 1,
                    'Non' => 0,
                ),
                'expanded' => true,
                'multiple' => false,
                'required' => true,
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => RefReferent::class,
        ]);
    }
}
