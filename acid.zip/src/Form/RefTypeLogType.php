<?php

namespace App\Form;

use App\Entity\RefTypeLog;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class RefTypeLogType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('libelle', TextType::class, [
                'label' => 'Libelle* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('actif', ChoiceType::class, [
                'label' => 'Actif*',
                'label_attr' => ['class' => 'radio-custom radio-inline'],
                'choices' => array(
                    'Oui' => 1,
                    'Non' => 0,
                ),
                'expanded' => true,
                'multiple' => false,
                'required' => true,
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => RefTypeLog::class,
        ]);
    }
}
