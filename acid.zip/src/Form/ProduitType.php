<?php

namespace App\Form;

use App\Entity\Produit;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProduitType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder

            ->add('nomProduitCommercial', TextType::class, [
                'label' => 'Nom* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('numCategorie', TextType::class, [
                'label' => 'Catégorie* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('dateDonneesSources', TextType::class, [
                'label' => 'DateDonneesSources* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('numType', TextType::class, [
                'label' => 'Type* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('nomSociete', TextType::class, [
                'label' => 'Société* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('numUrgence1', TextType::class, [
                'label' => 'Numéro d urgence 1* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('numUrgence2', TextType::class, [
                'label' => 'Numéro d urgence 2* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('numUrgence3', TextType::class, [
                'label' => 'Numéro d urgence 3* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('domaineAppli', TextType::class, [
                'label' => 'Domaine d application* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('conditionnement', TextType::class, [
                'label' => 'Conditionnement* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('miseEnOeuvre', TextType::class, [
                'label' => 'Mise en oeuvre* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('mortel', TextType::class, [
                'label' => 'Mortel* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('siteUtilisateur', TextType::class, [
                'label' => 'Site utilisateur* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('fournisseur', TextType::class, [
                'label' => 'Fournisseur* :',
                'attr' => ['placeholder' => ''],
                'row_attr' => ['class' => 'form-floating'],
                'required' => true,
                'mapped' => true,
            ])

            ->add('visible', ChoiceType::class, [
                'label' => 'Visible*',
                'label_attr' => ['class' => 'radio-custom radio-inline'],
                'choices' => array(
                    'Oui' => 1,
                    'Non' => 0,
                ),
                'expanded' => true,
                'multiple' => false,
                'required' => true,
            ]);
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Produit::class,
        ]);
    }
}
