<?php

namespace App\Controller\Admin;

use App\Entity\Pole;
use App\Entity\Utilisateur;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/admin/direction')]
#[IsGranted("ROLE_ADMIN")]
class DirectionController extends AbstractController
{
    #[Route('/select/{pole_id}/{utilisateur_id}', name: 'direction_select', options: ['expose' => true], methods: ['GET'])]
    #[ParamConverter('pole', options: ['mapping' => ['pole_id' => 'id']])]
    #[ParamConverter('utilisateur', options: ['mapping' => ['utilisateur_id' => 'id']])]
    public function select(Request $request, ?Pole $pole, ?Utilisateur $utilisateur): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        return $this->render('admin/direction/_select.html.twig', [
            'directions' => $pole->getActivesDirections($utilisateur),
        ]);
    }
}
