<?php

namespace App\Controller;

use App\Entity\Produit;
use App\Entity\Sites;
use App\Form\ProduitType;
use App\Repository\SitesRepository;
use App\Repository\RefEtatDemandeRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/produit')]
#[IsGranted("ROLE_ADMIN")]
class ProduitController extends AbstractController
{

    /*#[Route('/', name: 'produit_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager, SitesRepository $sitesRepository): Response
    {
dd("ici");
        $sites = $sitesRepository->findAllNameOrderBy();
        return $this->render('default/index.html.twig', [
            'produits' => $entityManager->getRepository(Produit::class)->findAll(),
            'les_sites' => $sites->getQuery()->getResult(),
        ]);
    }*/

    #[Route('/list/{page<\d+>?}', name: "produit_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');
        $siteUtilisateur = $request->get('site', '');
        //dd("ici");
        $entities = $entityManager
            ->getRepository(Produit::class)
            ->findByFilter($q, 0);

        $produits = $paginator->paginate($entities, $page, Produit::NUM_ITEMS);

        return $this->render('produit/_list.html.twig', [
            'produits' => $produits,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "produit_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $produit = new Produit();
        $produit->setCreatedAt(new \DateTime());
        $produit->setUpdatedAt(new \DateTime());
        $produit->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(ProduitType::class, $produit);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $produit->setCreatedAt(new \DateTime());

                $entityManager->persist($produit);
                $entityManager->flush();

                $this->addFlash('success', 'Produit créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce Produit existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce Produit existe déjà.");
            }
        }

        return $this->render('produit/_modal_new.html.twig', [
            'produit' => $produit,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{idProduit<\d+>}', name: "produit_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, Produit $produit, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(ProduitType::class, $produit);
        $form->handleRequest($request);
        $produit->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $produit->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/produit/_edit.html.twig', [
            'produit' => $produit,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{idProduit<\d+>}', name: 'produit_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, Produit $produit, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(ProduitType::class, $produit);
        $produit->setUpdatedAt(new \DateTime());
        $produit->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $produit->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le Produit a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationProduit = $request->request->get('produit')['nom'];
                //    $this->addFlash('danger', "Produit [" . $recuperationProduit . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce Produit existe déjà.");
            }
        }

        return $this->render('produit/_modal_edit.html.twig', [
            'produit' => $produit,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{idProduit}/delete', name: "produit_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, Produit $produit): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($produit);
            $entityManager->flush();

            $this->addFlash('success', 'Produit supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{idProduit}/delete', name: "produit_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, Produit $produit): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $produit->setVisible(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{idProduit}', name: "produit_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(produit $produit): Response
    {
        return $this->render('produit/_modal_show.html.twig', [
            'produit' => $produit,
        ]);
    }


    #[Route('/{idProduit}/deleteListe', name: 'produit_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(Produit $produit): Response
    {
        return $this->renderForm('produit/_deleteListe.html.twig', [
            'produit' => $produit,
        ]);
    }
}
