<?php

namespace App\Controller;

use App\Entity\RefNumTel;
use App\Form\RefNumTelType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/refNumTel')]
#[IsGranted("ROLE_ADMIN")]
class RefNumTelController extends AbstractController
{

    #[Route('/', name: 'refNumTel_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('refNumTel/index.html.twig', [
            'refNumTels' => $entityManager->getRepository(RefNumTel::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "refNumTel_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(RefNumTel::class)
            ->findByFilter($q);

        $refNumTels = $paginator->paginate($entities, $page, RefNumTel::NUM_ITEMS);

        return $this->render('refNumTel/_list.html.twig', [
            'refNumTels' => $refNumTels,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "refNumTel_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $refNumTel = new RefNumTel();
        $refNumTel->setCreatedAt(new \DateTime());
        $refNumTel->setUpdatedAt(new \DateTime());
        $refNumTel->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(RefNumTelType::class, $refNumTel);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $refNumTel->setCreatedAt(new \DateTime());

                $entityManager->persist($refNumTel);
                $entityManager->flush();

                $this->addFlash('success', 'Numéro créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce numéro existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('refNumTel/_modal_new.html.twig', [
            'refNumTel' => $refNumTel,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "refNumTel_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, RefNumTel $refNumTel, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(RefNumTelType::class, $refNumTel);
        $form->handleRequest($request);
        $refNumTel->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $refNumTel->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/refNumTel/_edit.html.twig', [
            'refNumTel' => $refNumTel,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'refNumTel_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, RefNumTel $refNumTel, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(RefNumTelType::class, $refNumTel);
        $refNumTel->setUpdatedAt(new \DateTime());
        $refNumTel->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $refNumTel->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le numéro a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationRefNumTel = $request->request->get('refNumTel')['libelle'];
                //    $this->addFlash('danger', "Numéro [" . $recuperationRefNumTel . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('refNumTel/_modal_edit.html.twig', [
            'refNumTel' => $refNumTel,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "refNumTel_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefNumTel $refNumTel): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($refNumTel);
            $entityManager->flush();

            $this->addFlash('success', 'Numéro supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "refNumTel_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefNumTel $refNumTel): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $refNumTel->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "refNumTel_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(refNumTel $refNumTel): Response
    {
        return $this->render('refNumTel/_modal_show.html.twig', [
            'refNumTel' => $refNumTel,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'refNumTel_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(RefNumTel $refNumTel): Response
    {
        return $this->renderForm('refNumTel/_deleteListe.html.twig', [
            'refNumTel' => $refNumTel,
        ]);
    }
}
