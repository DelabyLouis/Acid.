<?php

namespace App\Controller;

use App\Entity\RefDechet;
use App\Form\RefDechetType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/refDechet')]
#[IsGranted("ROLE_ADMIN")]
class RefDechetController extends AbstractController
{

    #[Route('/', name: 'refDechet_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('refDechet/index.html.twig', [
            'refDechets' => $entityManager->getRepository(RefDechet::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "refDechet_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(RefDechet::class)
            ->findByFilter($q);

        $refDechets = $paginator->paginate($entities, $page, RefDechet::NUM_ITEMS);

        return $this->render('refDechet/_list.html.twig', [
            'refDechets' => $refDechets,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "refDechet_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $refDechet = new RefDechet();
        $refDechet->setCreatedAt(new \DateTime());
        $refDechet->setUpdatedAt(new \DateTime());
        $refDechet->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(RefDechetType::class, $refDechet);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $refDechet->setCreatedAt(new \DateTime());

                $entityManager->persist($refDechet);
                $entityManager->flush();

                $this->addFlash('success', 'Type créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce type existe déjà.');
            } catch (Exception $e) {
                dd($e);
                $this->addFlash('danger', "Ce type existe déjà.");
            }
        }

        return $this->render('refDechet/_modal_new.html.twig', [
            'refDechet' => $refDechet,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "refDechet_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, RefDechet $refDechet, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(RefDechetType::class, $refDechet);
        $form->handleRequest($request);
        $refDechet->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $refDechet->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/refDechet/_edit.html.twig', [
            'refDechet' => $refDechet,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'refDechet_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, RefDechet $refDechet, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(RefDechetType::class, $refDechet);
        $refDechet->setUpdatedAt(new \DateTime());
        $refDechet->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $refDechet->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le type a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationRefDechet = $request->request->get('refDechet')['libelle'];
                //    $this->addFlash('danger', "Type [" . $recuperationRefDechet . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce type existe déjà.");
            }
        }

        return $this->render('refDechet/_modal_edit.html.twig', [
            'refDechet' => $refDechet,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "refDechet_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefDechet $refDechet): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($refDechet);
            $entityManager->flush();

            $this->addFlash('success', 'Type supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "refDechet_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefDechet $refDechet): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $refDechet->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "refDechet_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(refDechet $refDechet): Response
    {
        return $this->render('refDechet/_modal_show.html.twig', [
            'refDechet' => $refDechet,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'refDechet_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(RefDechet $refDechet): Response
    {
        return $this->renderForm('refDechet/_deleteListe.html.twig', [
            'refDechet' => $refDechet,
        ]);
    }
}
