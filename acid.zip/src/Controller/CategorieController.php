<?php

namespace App\Controller;

use App\Entity\Categorie;
use App\Form\CategorieType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/categorie')]
#[IsGranted("ROLE_ADMIN")]
class CategorieController extends AbstractController
{

    #[Route('/', name: 'categorie_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('categorie/index.html.twig', [
            'categories' => $entityManager->getRepository(Categorie::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "categorie_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(Categorie::class)
            ->findByFilter($q);

        $categories = $paginator->paginate($entities, $page, Categorie::NUM_ITEMS);

        return $this->render('categorie/_list.html.twig', [
            'categories' => $categories,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "categorie_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $categorie = new Categorie();
        $categorie->setCreatedAt(new \DateTime());
        $categorie->setUpdatedAt(new \DateTime());
        $categorie->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(CategorieType::class, $categorie);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $categorie->setCreatedAt(new \DateTime());

                $entityManager->persist($categorie);
                $entityManager->flush();

                $this->addFlash('success', 'Numéro créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce numéro existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('categorie/_modal_new.html.twig', [
            'categorie' => $categorie,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "categorie_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, Categorie $categorie, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(CategorieType::class, $categorie);
        $form->handleRequest($request);
        $categorie->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $categorie->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/categorie/_edit.html.twig', [
            'categorie' => $categorie,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'categorie_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, Categorie $categorie, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(CategorieType::class, $categorie);
        $categorie->setUpdatedAt(new \DateTime());
        $categorie->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $categorie->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le numéro a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationCategorie = $request->request->get('categorie')['nom'];
                //    $this->addFlash('danger', "Numéro [" . $recuperationCategorie . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('categorie/_modal_edit.html.twig', [
            'categorie' => $categorie,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "categorie_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, Categorie $categorie): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($categorie);
            $entityManager->flush();

            $this->addFlash('success', 'Numéro supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "categorie_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, Categorie $categorie): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $categorie->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "categorie_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(categorie $categorie): Response
    {
        return $this->render('categorie/_modal_show.html.twig', [
            'categorie' => $categorie,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'categorie_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(Categorie $categorie): Response
    {
        return $this->renderForm('categorie/_deleteListe.html.twig', [
            'categorie' => $categorie,
        ]);
    }
}
