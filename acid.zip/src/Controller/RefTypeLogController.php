<?php

namespace App\Controller;

use App\Entity\RefTypeLog;
use App\Form\RefTypeLogType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/refTypeLog')]
#[IsGranted("ROLE_ADMIN")]
class RefTypeLogController extends AbstractController
{

    #[Route('/', name: 'refTypeLog_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('refTypeLog/index.html.twig', [
            'refTypeLogs' => $entityManager->getRepository(RefTypeLog::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "refTypeLog_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(RefTypeLog::class)
            ->findByFilter($q);

        $refTypeLogs = $paginator->paginate($entities, $page, RefTypeLog::NUM_ITEMS);

        return $this->render('refTypeLog/_list.html.twig', [
            'refTypeLogs' => $refTypeLogs,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "refTypeLog_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $refTypeLog = new RefTypeLog();
        $refTypeLog->setCreatedAt(new \DateTime());
        $refTypeLog->setUpdatedAt(new \DateTime());
        $refTypeLog->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(RefTypeLog::class, $refTypeLog);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $refTypeLog->setCreatedAt(new \DateTime());

                $entityManager->persist($refTypeLog);
                $entityManager->flush();

                $this->addFlash('success', 'Référent créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce référent existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce référent existe déjà.");
            }
        }

        return $this->render('refTypeLog/_modal_new.html.twig', [
            'refTypeLog' => $refTypeLog,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "refTypeLog_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, RefTypeLog $refTypeLog, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(RefTypeLogType::class, $refTypeLog);
        $form->handleRequest($request);
        $refTypeLog->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $refTypeLog->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/refTypeLog/_edit.html.twig', [
            'refTypeLog' => $refTypeLog,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'refTypeLog_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, RefTypeLog $refTypeLog, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(RefTypeLogType::class, $refTypeLog);
        $refTypeLog->setUpdatedAt(new \DateTime());
        $refTypeLog->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $refTypeLog->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le référent a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationRefTypeLog = $request->request->get('refTypeLog')['libelle'];
                //    $this->addFlash('danger', "Référent [" . $recuperationRefTypeLog . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce référent existe déjà.");
            }
        }

        return $this->render('refTypeLog/_modal_edit.html.twig', [
            'refTypeLog' => $refTypeLog,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "refTypeLog_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefTypeLog $refTypeLog): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($refTypeLog);
            $entityManager->flush();

            $this->addFlash('success', 'Référent supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "refTypeLog_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefTypeLog $refTypeLog): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $refTypeLog->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "refTypeLog_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(refTypeLog $refTypeLog): Response
    {
        return $this->render('refTypeLog/_modal_show.html.twig', [
            'refTypeLog' => $refTypeLog,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'refTypeLog_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(RefTypeLog $refTypeLog): Response
    {
        return $this->renderForm('refTypeLog/_deleteListe.html.twig', [
            'refTypeLog' => $refTypeLog,
        ]);
    }
}
