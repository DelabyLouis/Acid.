<?php

namespace App\Controller;

use App\Entity\Actualite;
use App\Entity\Structure;
use App\Repository\SitesRepository;
use App\Services\Captcha;
use App\Services\Chiffre;
use App\Services\Ldap;
use App\Services\Organigramme;
use App\Services\Sig;
use Doctrine\ORM\EntityManagerInterface;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;

class DefaultController extends AbstractController
{
    #[Route('/', name: 'default_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager, SitesRepository $sitesRepository): Response
    {
        //dd("ici");
        $sites = $sitesRepository->findAllNameOrderBy();
        return $this->render('default/index.html.twig', [
            'les_sites' => $sites->getQuery()->getResult(),
        ]);
    }

    /*#[Route('/{actualite_id<\d+>?}', name: "default_index", methods: ['GET'])]
    #[ParamConverter('actualite', options: ['mapping' => ['actualite_id' => 'id']])]
    #[IsGranted('ROLE_USER')]
    public function index(EntityManagerInterface $entityManager, ?Actualite $actualite): Response
    {
        $actualite_nav = [];
        // Récup des actus
        $actualites = $entityManager->getRepository(Actualite::class)->findBy(['statut' => Actualite::STATUTS[0]], ['createdAt' => 'DESC']);

        // Si l'actu n'est pas fournie, on récupère la dernière
        if ($actualite) {
            $actualite_id = $actualite->getId();
        } else if (count($actualites) > 0) {
            $actualite = $actualites[0];
            $actualite_id = $actualite->getId();
        } else {
            $actualite_id = 0;
        }

        // Récup des liens suivant et précédent
        $actualite_nav['total'] = count($actualites);
        foreach ($actualites as $i => $entity) {
            if ($entity->getId() == $actualite_id) {
                $actualite_nav['previous'] = isset($actualites[$i - 1]) ? $actualites[$i - 1]->getId() : null;
                $actualite_nav['next'] = isset($actualites[$i + 1]) ? $actualites[$i + 1]->getId() : null;
                $actualite_nav['position'] = $i + 1;
            }
        }

        return $this->render('default/index.html.twig', [
            'actualite' => $actualite,
            'actualite_nav' => $actualite_nav,
        ]);
    }*/

    #[Route('/demo', name: "default_demo", methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function demo(Chiffre $chiffre, Captcha $captcha): Response
    {
        $chaine = "Belle chaîne à chiffrer !";
        $encrypt = $chiffre->encrypt($chaine);
        $decrypt = $chiffre->decrypt($encrypt);

        // Stats Captcha sur les 6 derniers mois
        $captcha_valides = [];
        $captcha_non_valides = [];
        $captcha_expires = [];

        for ($i = 5; $i >= 0; $i--) {
            $date = new \DateTimeImmutable();

            $start = $date->modify("midnight first day of -$i months");

            // Dernier jour du mois ou jour actuel
            if ($i == 0) {
                $end = $date->modify("today")->setTime(23, 59, 59);
            } else {
                $end = $date->modify("last day of -$i months")->setTime(23, 59, 59);
            }

            $captchaStats = $captcha->getStatistiques($start->format('Y-m-d'), $end->format('Y-m-d'));

            if ($captchaStats) {
                $captcha_valides[] = ['x' => $end->getTimestamp() * 1000, 'y' => $captchaStats->captcha_ok];
                $captcha_non_valides[] = ['x' => $end->getTimestamp() * 1000, 'y' => $captchaStats->captcha_ko];
                $captcha_expires[] = ['x' => $end->getTimestamp() * 1000, 'y' => $captchaStats->captcha_expired];
            }
        }

        return $this->render('default/demo.html.twig', [
            'chaine' => $chaine,
            'encrypt' => $encrypt,
            'decrypt' => $decrypt,
            'captcha_valides' => ($captcha_valides),
            'captcha_non_valides' => ($captcha_non_valides),
            'captcha_expires' => ($captcha_expires),
        ]);
    }

    #[Route('/version', name: "default_version", methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function version(): Response
    {
        return $this->render('default/version.html.twig');
    }

    #[Route('/failed', name: "default_failed", methods: ['GET'])]
    public function failed(): Response
    {
        return $this->render('default/failed.html.twig');
    }

    #[Route('/logout', name: "default_logout", methods: ['GET'])]
    public function logout(Request $request): Response
    {
        $request->getSession()->invalidate();

        $response = new Response();
        $response->headers->clearCookie('PHPSESSID');

        return $this->render('default/logout.html.twig', [], $response);
    }

    #[Route('/profil', name: "default_profil", methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function profil(): Response
    {
        return $this->render('default/profil.html.twig');
    }

    #[Route('/test', name: "default_test", methods: ['GET'])]
    #[IsGranted('ROLE_SUPER_ADMIN')]
    public function test(): Response
    {
        return $this->render('default/test.html.twig');
    }

    /**
     * Retourne un tableau d'utilisateurs AD avec nom et login en fonction du nom
     */
    #[Route('/ldapsearch/{q}', name: "ldap_search", options: ['expose' => true], methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function ldapSearch(Ldap $ldap, string $q = ''): Response
    {
        $users = $ldap->findUsersByName($q);
        $return = [];

        foreach ($users as $i => $user) {
            if ($ldap->getNom($user)) {
                $return[$i]['civilite'] = $ldap->getCivilite($user);
                $return[$i]['value'] = $ldap->getNom($user) . ' ' . $ldap->getPrenom($user);
                $return[$i]['login'] = $ldap->getLogin($user);
                $return[$i]['fonction'] = $ldap->getFonction($user);
                $return[$i]['sigle'] = $ldap->getDirectionSigle($user);
            }
        }

        // Tri sur le nom
        foreach ($return as $i => $row) {
            $value[$i] = $row['value'];
            $login[$i] = $row['login'];
            $fonction[$i] = $row['fonction'];
        }
        if ($return) {
            array_multisort($value, SORT_ASC, $login, SORT_ASC, $return);
        }


        return new Response(json_encode($return, JSON_THROW_ON_ERROR));
    }

    /**
     * Retourne un json pour autocomplétion d'adresse postale
     */
    #[Route('/adressepostale/{q}/{code_insee?}', name: "adresse_postale", options: ['expose' => true], defaults: ['code_insee' => ''], methods: ['GET'])]
    #[IsGranted('ROLE_USER')]
    public function adressePostale(Request $request, Sig $sig, string $q, string $code_insee = ''): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        return new Response($sig->findAdresses($q, $code_insee));
    }

    #[Route('/calculdistance', name: "default_calculdistance", options: ['expose' => true], methods: ['POST'])]
    #[IsGranted('ROLE_USER')]
    public function calculDistance(Request $request, Sig $sig): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        return new Response($sig->calculItineraire(
            $request->get('startX'),
            $request->get('startY'),
            $request->get('endX'),
            $request->get('endY')
        ));
    }

    /**
     * Retourne un json d'événements
     */
    #[Route('/calendar', name: "fullcalendar", options: ['expose' => true], methods: ['POST'])]
    #[IsGranted('ROLE_USER')]
    public function calendar(Request $request): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $today = new \DateTime();

        $events = [
            [
                'id' => 1,
                'title' => 'TOTO',
                'start' => $today->format('Y-m-d'),
                'textColor' => '#FFFFFF',
            ], [
                'id' => 2,
                'title' => 'TATA',
                'start' => $today->modify('+1 day')->format('Y-m-d'),
                'textColor' => '#FFFFFF',
            ]
        ];

        return new Response(json_encode($events));
    }
}
