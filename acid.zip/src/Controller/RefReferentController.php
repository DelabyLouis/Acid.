<?php

namespace App\Controller;

use App\Entity\RefReferent;
use App\Form\RefReferentType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/refReferent')]
#[IsGranted("ROLE_ADMIN")]
class RefReferentController extends AbstractController
{

    #[Route('/', name: 'refReferent_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('refReferent/index.html.twig', [
            'refReferents' => $entityManager->getRepository(RefReferent::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "refReferent_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(RefReferent::class)
            ->findByFilter($q);

        $refReferents = $paginator->paginate($entities, $page, RefReferent::NUM_ITEMS);

        return $this->render('refReferent/_list.html.twig', [
            'refReferents' => $refReferents,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "refReferent_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $refReferent = new RefReferent();
        $refReferent->setCreatedAt(new \DateTime());
        $refReferent->setUpdatedAt(new \DateTime());
        $refReferent->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(RefReferentType::class, $refReferent);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $refReferent->setCreatedAt(new \DateTime());

                $entityManager->persist($refReferent);
                $entityManager->flush();

                $this->addFlash('success', 'Référent créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce référent existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce référent existe déjà.");
            }
        }

        return $this->render('refReferent/_modal_new.html.twig', [
            'refReferent' => $refReferent,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "refReferent_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, RefReferent $refReferent, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(RefReferentType::class, $refReferent);
        $form->handleRequest($request);
        $refReferent->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $refReferent->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/refReferent/_edit.html.twig', [
            'refReferent' => $refReferent,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'refReferent_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, RefReferent $refReferent, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(RefReferentType::class, $refReferent);
        $refReferent->setUpdatedAt(new \DateTime());
        $refReferent->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $refReferent->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le référent a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationRefReferent = $request->request->get('refReferent')['nom'];
                //    $this->addFlash('danger', "Référent [" . $recuperationRefReferent . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce référent existe déjà.");
            }
        }

        return $this->render('refReferent/_modal_edit.html.twig', [
            'refReferent' => $refReferent,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "refReferent_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefReferent $refReferent): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($refReferent);
            $entityManager->flush();

            $this->addFlash('success', 'Référent supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "refReferent_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, RefReferent $refReferent): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $refReferent->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "refReferent_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(refReferent $refReferent): Response
    {
        return $this->render('refReferent/_modal_show.html.twig', [
            'refReferent' => $refReferent,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'refReferent_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(RefReferent $refReferent): Response
    {
        return $this->renderForm('refReferent/_deleteListe.html.twig', [
            'refReferent' => $refReferent,
        ]);
    }
}
