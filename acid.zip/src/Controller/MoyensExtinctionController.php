<?php

namespace App\Controller;

use App\Entity\MoyensExtinction;
use App\Form\MoyensExtinctionType;
use App\Repository\UtilisateurRepository;
use Doctrine\DBAL\Exception\UniqueConstraintViolationException;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\IsGranted;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;
use Doctrine\ORM\EntityManagerInterface;
use Exception;
use Knp\Component\Pager\PaginatorInterface;
use Symfony\Component\HttpFoundation\RedirectResponse;



#[Route('/moyensExtinction')]
#[IsGranted("ROLE_ADMIN")]
class MoyensExtinctionController extends AbstractController
{

    #[Route('/', name: 'moyensExtinction_index', methods: ['GET'], options: ['expose' => true])]
    public function index(EntityManagerInterface $entityManager): Response
    {

        return $this->render('moyensExtinction/index.html.twig', [
            'moyensExtinctions' => $entityManager->getRepository(MoyensExtinction::class)->findAll(),
        ]);
    }

    #[Route('/list/{page<\d+>?}', name: "moyensExtinction_list", methods: ['GET', 'POST'])]
    public function list(?int $page, Request $request, EntityManagerInterface $entityManager, PaginatorInterface $paginator): Response
    {
        if (!$request->isXmlHttpRequest()) {
            throw $this->createAccessDeniedException();
        }

        $q = $request->get('q', '');

        $entities = $entityManager
            ->getRepository(MoyensExtinction::class)
            ->findByFilter($q);

        $moyensExtinctions = $paginator->paginate($entities, $page, MoyensExtinction::NUM_ITEMS);

        return $this->render('moyensExtinction/_list.html.twig', [
            'moyensExtinctions' => $moyensExtinctions,
            'q' => $q,
        ]);
    }

    #[Route('/modal/new', name: "moyensExtinction_modal_new", methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalNew(Request $request, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): Response
    {

        $moyensExtinction = new MoyensExtinction();
        $moyensExtinction->setCreatedAt(new \DateTime());
        $moyensExtinction->setUpdatedAt(new \DateTime());
        $moyensExtinction->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        $form = $this->createForm(MoyensExtinctionType::class, $moyensExtinction);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {

                $moyensExtinction->setCreatedAt(new \DateTime());

                $entityManager->persist($moyensExtinction);
                $entityManager->flush();

                $this->addFlash('success', 'Numéro créée');

                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    return new Response('Ce numéro existe déjà.');
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('moyensExtinction/_modal_new.html.twig', [
            'moyensExtinction' => $moyensExtinction,
            'form' => $form->createView(),
        ]);
    }

    /*
    #[Route('/edit/{id<\d+>}', name: "moyensExtinction_edit", methods: ['GET', 'POST'])]
    public function edit(Request $request, EntityManagerInterface $entityManager, MoyensExtinction $moyensExtinction, UtilisateurRepository $utilisateurRepository): Response
    {
        $form = $this->createForm(MoyensExtinctionType::class, $moyensExtinction);
        $form->handleRequest($request);
        $moyensExtinction->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);

        if ($form->isSubmitted() && $form->isValid()) {
            $moyensExtinction->setUpdatedAt(new \DateTime());

            $entityManager->flush();

            return new Response('ok');
        }

        return $this->render('admin/moyensExtinction/_edit.html.twig', [
            'moyensExtinction' => $moyensExtinction,
            'form' => $form->createView(),
        ]);
    }
*/

    #[Route('/modal/edit/{id<\d+>}', name: 'moyensExtinction_modal_edit', methods: ['GET', 'POST'], options: ['expose' => true])]
    public function modalEdit(Request $request, MoyensExtinction $moyensExtinction, EntityManagerInterface $entityManager, UtilisateurRepository $utilisateurRepository): RedirectResponse|Response
    {
        $form = $this->createForm(MoyensExtinctionType::class, $moyensExtinction);
        $moyensExtinction->setUpdatedAt(new \DateTime());
        $moyensExtinction->setUpdatedBy($utilisateurRepository->findByLogin($this->getUser()->getLogin())->getResult()[0]);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {

            try {
                $moyensExtinction->setUpdatedAt(new \DateTime());
                $entityManager->flush();
                $this->addFlash('success', 'Le numéro a été modifié');
                return new Response('ok');
                //} catch (UniqueConstraintViolationException $e) {
                //    $recuperationMoyensExtinction = $request->request->get('moyensExtinction')['libelle'];
                //    $this->addFlash('danger', "Numéro [" . $recuperationMoyensExtinction . "] existe déjà");
            } catch (Exception $e) {
                $this->addFlash('danger', "Ce numéro existe déjà.");
            }
        }

        return $this->render('moyensExtinction/_modal_edit.html.twig', [
            'moyensExtinction' => $moyensExtinction,
            'form' => $form->createView(),
        ]);
    }

    #[Route('{id}/delete', name: "moyensExtinction_modal_delete", methods: ['GET', 'POST', 'DELETE'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, MoyensExtinction $moyensExtinction): Response
    {

        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {

            $entityManager->remove($moyensExtinction);
            $entityManager->flush();

            $this->addFlash('success', 'Numéro supprimé');

            // // MAJ des logs
            // $util = new Util();
            // $util->ligne_log('Suppression programmation' , 'Programmation ['. $idTypo.']' , $this->getUser()->getLogin() , $entityManager);

            return new Response('ok');
        } catch (\Exception $e) {
            $this->addFlash('danger', 'Suppression impossible');
            return new Response('Suppression impossible');
        }
    }

    /*
    #[Route('{id}/delete', name: "moyensExtinction_modal_delete", methods: ['GET', 'POST'])]
    public function delete(Request $request, EntityManagerInterface $entityManager, MoyensExtinction $moyensExtinction): Response
    {
        if (!$this->isCsrfTokenValid('delete', $request->request->get('token'))) {
            return new Response('Erreur : token non valide');
        }

        try {
            //dd("ici");
            $moyensExtinction->setActif(0);
            $entityManager->flush();

            return new Response('ok');
        } catch (Exception $erreur) {
            return new Response($erreur);
        }
    }
*/

    #[Route('/modal/show/{id}', name: "moyensExtinction_modal_show", methods: ['GET'], options: ['expose' => true])]
    public function modalShow(moyensExtinction $moyensExtinction): Response
    {
        return $this->render('moyensExtinction/_modal_show.html.twig', [
            'moyensExtinction' => $moyensExtinction,
        ]);
    }


    #[Route('/{id}/deleteListe', name: 'moyensExtinction_deleteListe', methods: ['GET', 'POST'])]
    public function deleteListe(MoyensExtinction $moyensExtinction): Response
    {
        return $this->renderForm('moyensExtinction/_deleteListe.html.twig', [
            'moyensExtinction' => $moyensExtinction,
        ]);
    }
}
