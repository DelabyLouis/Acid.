<?php

namespace App\Repository;

use App\Entity\RefReferent;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<RefReferent>
 *
 * @method RefReferent|null find($id, $lockMode = null, $lockVersion = null)
 * @method RefReferent|null findOneBy(array $criteria, array $orderBy = null)
 * @method RefReferent[]    findAll()
 * @method RefReferent[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */

class RefReferentRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, RefReferent::class);
    }

    public function save(RefReferent $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(RefReferent $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function findByFilter(string $q)
    {
        $queryBuilder = $this
            ->createQueryBuilder('a')
            ->orderBy('a.updatedAt', 'DESC');

        if ($q) {
            $queryBuilder
                ->orWhere('a.nom LIKE :q')
                ->orWhere('a.prenom LIKE :q')
                ->orWhere('a.organismeBeneficiaire LIKE :q')
                ->orWhere('a.adresse LIKE :q')
                ->orWhere('a.cp LIKE :q')
                ->orWhere('a.ville LIKE :q')
                ->orWhere('a.mail LIKE :q')
                ->setParameter('q', "%$q%");
        }

        return $queryBuilder->getQuery();
    }

    //    /**
    //     * @return RefReferent[] Returns an array of RefReferent objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('s.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?RefReferent
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
