<?php

namespace App\Repository;

use App\Entity\RefTypeLog;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<RefTypeLog>
 *
 * @method RefTypeLog|null find($id, $lockMode = null, $lockVersion = null)
 * @method RefTypeLog|null findOneBy(array $criteria, array $orderBy = null)
 * @method RefTypeLog[]    findAll()
 * @method RefTypeLog[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */

class RefTypeLogRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, RefTypeLog::class);
    }

    public function save(RefTypeLog $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(RefTypeLog $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function findByFilter(string $q)
    {
        $queryBuilder = $this
            ->createQueryBuilder('a')
            ->orderBy('a.updatedAt', 'DESC');

        if ($q) {
            $queryBuilder
                ->orWhere('a.libelle LIKE :q')
                ->setParameter('q', "%$q%");
        }

        return $queryBuilder->getQuery();
    }

    //    /**
    //     * @return RefTypeLog[] Returns an array of RefTypeLog objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('s.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?RefTypeLog
    //    {
    //        return $this->createQueryBuilder('s')
    //            ->andWhere('s.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
