<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ConditionsElimination
 */
#[ORM\Table(name: 'conditions_elimination')]
#[ORM\Index(name: 'conditions_elimination_no_fk1', columns: ['CATALOGUE_PDT'])]
#[ORM\Index(name: 'conditions_elimination_no_fk2', columns: ['CATALOGUE_EMBALLAGE'])]
#[ORM\Index(name: 'conditions_elimination_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class ConditionsElimination
{
    #[ORM\Column(name: 'ID_ELIMINATION', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idElimination;

    #[ORM\Column(name: 'ELIMINATION_PRODUIT', type: 'string', length: 3000, nullable: true)]
    private ?string $eliminationProduit = null;

    #[ORM\Column(name: 'ELIMINATION_EMBALL_SOUILLES', type: 'string', length: 3000, nullable: true)]
    private ?string $eliminationEmballSouilles = null;

    #[ORM\Column(name: 'PDT_DANGEREUX', type: 'integer', nullable: true)]
    private ?int $pdtDangereux = null;

    #[ORM\Column(name: 'EMBALLAGE_DANGEREUX', type: 'integer', nullable: true)]
    private ?int $emballageDangereux = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    #[ORM\JoinColumn(name: 'CATALOGUE_PDT', referencedColumnName: 'ID')]
    #[ORM\ManyToOne(targetEntity: 'NomenclatureDechets')]
    private readonly \App\Entity\NomenclatureDechets $cataloguePdt;

    #[ORM\JoinColumn(name: 'CATALOGUE_EMBALLAGE', referencedColumnName: 'ID')]
    #[ORM\ManyToOne(targetEntity: 'NomenclatureDechets')]
    private readonly \App\Entity\NomenclatureDechets $catalogueEmballage;

    public function getIdElimination(): ?int
    {
        return $this->idElimination;
    }

    public function getEliminationProduit(): ?string
    {
        return $this->eliminationProduit;
    }

    public function setEliminationProduit(?string $eliminationProduit): self
    {
        $this->eliminationProduit = $eliminationProduit;

        return $this;
    }

    public function getEliminationEmballSouilles(): ?string
    {
        return $this->eliminationEmballSouilles;
    }

    public function setEliminationEmballSouilles(?string $eliminationEmballSouilles): self
    {
        $this->eliminationEmballSouilles = $eliminationEmballSouilles;

        return $this;
    }

    public function getPdtDangereux(): ?int
    {
        return $this->pdtDangereux;
    }

    public function setPdtDangereux(?int $pdtDangereux): self
    {
        $this->pdtDangereux = $pdtDangereux;

        return $this;
    }

    public function getEmballageDangereux(): ?int
    {
        return $this->emballageDangereux;
    }

    public function setEmballageDangereux(?int $emballageDangereux): self
    {
        $this->emballageDangereux = $emballageDangereux;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }

    public function getCataloguePdt(): ?NomenclatureDechets
    {
        return $this->cataloguePdt;
    }

    public function setCataloguePdt(?NomenclatureDechets $cataloguePdt): self
    {
        $this->cataloguePdt = $cataloguePdt;

        return $this;
    }

    public function getCatalogueEmballage(): ?NomenclatureDechets
    {
        return $this->catalogueEmballage;
    }

    public function setCatalogueEmballage(?NomenclatureDechets $catalogueEmballage): self
    {
        $this->catalogueEmballage = $catalogueEmballage;

        return $this;
    }


}
