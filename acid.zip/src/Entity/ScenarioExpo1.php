<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * ScenarioExpo1
 */
#[ORM\Table(name: 'scenario_expo1')]
#[ORM\Index(name: 'scenario_expo1_fk3', columns: ['CHPS_SUPP_DESC2'])]
#[ORM\Index(name: 'scenario_expo1_fk4', columns: ['CHPS_SUPP_DESC3'])]
#[ORM\Index(name: 'scenario_expo1_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Index(name: 'scenario_expo1_fk5', columns: ['CHPS_SUPP_DESC4'])]
#[ORM\Index(name: 'scenario_expo1_fk2', columns: ['CHPS_SUPP_DESC1'])]
#[ORM\Entity]
class ScenarioExpo1
{
    #[ORM\Column(name: 'ID_SCENARIO_EXPO1', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idScenarioExpo1;

    #[ORM\Column(name: 'SECTEUR_UTILISATION', type: 'string', length: 200, nullable: true)]
    private ?string $secteurUtilisation = null;

    #[ORM\Column(name: 'ETAT_PHYSIQUE', type: 'string', length: 200, nullable: true)]
    private ?string $etatPhysique = null;

    #[ORM\Column(name: 'CONCENTRATION_SUBSTANCE', type: 'string', length: 200, nullable: true)]
    private ?string $concentrationSubstance = null;

    #[ORM\Column(name: 'FREQUENCE_DUREE_UTILISATION', type: 'string', length: 200, nullable: true)]
    private ?string $frequenceDureeUtilisation = null;

    #[ORM\Column(name: 'AUTRES_CONDITIONS_OP', type: 'string', length: 200, nullable: true)]
    private ?string $autresConditionsOp = null;

    #[ORM\Column(name: 'MESURES_GENERALES', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresGenerales = null;

    #[ORM\Column(name: 'MESURES_GENERALES_PEAU', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresGeneralesPeau = null;

    #[ORM\Column(name: 'MESURES_GENERALES_RESPIRATOIRE', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresGeneralesRespiratoire = null;

    #[ORM\Column(name: 'MESURES_GENERALES_DIGESTIVE', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresGeneralesDigestive = null;

    #[ORM\Column(name: 'CHPS_SUPP_VAL1', type: 'text', length: 0, nullable: true)]
    private ?string $chpsSuppVal1 = null;

    #[ORM\Column(name: 'CHPS_SUPP_VAL2', type: 'text', length: 0, nullable: true)]
    private ?string $chpsSuppVal2 = null;

    #[ORM\Column(name: 'CHPS_SUPP_VAL3', type: 'text', length: 0, nullable: true)]
    private ?string $chpsSuppVal3 = null;

    #[ORM\Column(name: 'CHPS_SUPP_VAL4', type: 'text', length: 0, nullable: true)]
    private ?string $chpsSuppVal4 = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    #[ORM\JoinColumn(name: 'CHPS_SUPP_DESC3', referencedColumnName: 'ID_REF_CHPS_SUPP_SCENARIO_EXPO')]
    #[ORM\ManyToOne(targetEntity: 'RefChpsSuppScenarioExpo')]
    private readonly \App\Entity\RefChpsSuppScenarioExpo $chpsSuppDesc3;

    #[ORM\JoinColumn(name: 'CHPS_SUPP_DESC1', referencedColumnName: 'ID_REF_CHPS_SUPP_SCENARIO_EXPO')]
    #[ORM\ManyToOne(targetEntity: 'RefChpsSuppScenarioExpo')]
    private readonly \App\Entity\RefChpsSuppScenarioExpo $chpsSuppDesc1;

    #[ORM\JoinColumn(name: 'CHPS_SUPP_DESC4', referencedColumnName: 'ID_REF_CHPS_SUPP_SCENARIO_EXPO')]
    #[ORM\ManyToOne(targetEntity: 'RefChpsSuppScenarioExpo')]
    private readonly \App\Entity\RefChpsSuppScenarioExpo $chpsSuppDesc4;

    #[ORM\JoinColumn(name: 'CHPS_SUPP_DESC2', referencedColumnName: 'ID_REF_CHPS_SUPP_SCENARIO_EXPO')]
    #[ORM\ManyToOne(targetEntity: 'RefChpsSuppScenarioExpo')]
    private readonly \App\Entity\RefChpsSuppScenarioExpo $chpsSuppDesc2;

    public function getIdScenarioExpo1(): ?int
    {
        return $this->idScenarioExpo1;
    }

    public function getSecteurUtilisation(): ?string
    {
        return $this->secteurUtilisation;
    }

    public function setSecteurUtilisation(?string $secteurUtilisation): self
    {
        $this->secteurUtilisation = $secteurUtilisation;

        return $this;
    }

    public function getEtatPhysique(): ?string
    {
        return $this->etatPhysique;
    }

    public function setEtatPhysique(?string $etatPhysique): self
    {
        $this->etatPhysique = $etatPhysique;

        return $this;
    }

    public function getConcentrationSubstance(): ?string
    {
        return $this->concentrationSubstance;
    }

    public function setConcentrationSubstance(?string $concentrationSubstance): self
    {
        $this->concentrationSubstance = $concentrationSubstance;

        return $this;
    }

    public function getFrequenceDureeUtilisation(): ?string
    {
        return $this->frequenceDureeUtilisation;
    }

    public function setFrequenceDureeUtilisation(?string $frequenceDureeUtilisation): self
    {
        $this->frequenceDureeUtilisation = $frequenceDureeUtilisation;

        return $this;
    }

    public function getAutresConditionsOp(): ?string
    {
        return $this->autresConditionsOp;
    }

    public function setAutresConditionsOp(?string $autresConditionsOp): self
    {
        $this->autresConditionsOp = $autresConditionsOp;

        return $this;
    }

    public function getMesuresGenerales(): ?string
    {
        return $this->mesuresGenerales;
    }

    public function setMesuresGenerales(?string $mesuresGenerales): self
    {
        $this->mesuresGenerales = $mesuresGenerales;

        return $this;
    }

    public function getMesuresGeneralesPeau(): ?string
    {
        return $this->mesuresGeneralesPeau;
    }

    public function setMesuresGeneralesPeau(?string $mesuresGeneralesPeau): self
    {
        $this->mesuresGeneralesPeau = $mesuresGeneralesPeau;

        return $this;
    }

    public function getMesuresGeneralesRespiratoire(): ?string
    {
        return $this->mesuresGeneralesRespiratoire;
    }

    public function setMesuresGeneralesRespiratoire(?string $mesuresGeneralesRespiratoire): self
    {
        $this->mesuresGeneralesRespiratoire = $mesuresGeneralesRespiratoire;

        return $this;
    }

    public function getMesuresGeneralesDigestive(): ?string
    {
        return $this->mesuresGeneralesDigestive;
    }

    public function setMesuresGeneralesDigestive(?string $mesuresGeneralesDigestive): self
    {
        $this->mesuresGeneralesDigestive = $mesuresGeneralesDigestive;

        return $this;
    }

    public function getChpsSuppVal1(): ?string
    {
        return $this->chpsSuppVal1;
    }

    public function setChpsSuppVal1(?string $chpsSuppVal1): self
    {
        $this->chpsSuppVal1 = $chpsSuppVal1;

        return $this;
    }

    public function getChpsSuppVal2(): ?string
    {
        return $this->chpsSuppVal2;
    }

    public function setChpsSuppVal2(?string $chpsSuppVal2): self
    {
        $this->chpsSuppVal2 = $chpsSuppVal2;

        return $this;
    }

    public function getChpsSuppVal3(): ?string
    {
        return $this->chpsSuppVal3;
    }

    public function setChpsSuppVal3(?string $chpsSuppVal3): self
    {
        $this->chpsSuppVal3 = $chpsSuppVal3;

        return $this;
    }

    public function getChpsSuppVal4(): ?string
    {
        return $this->chpsSuppVal4;
    }

    public function setChpsSuppVal4(?string $chpsSuppVal4): self
    {
        $this->chpsSuppVal4 = $chpsSuppVal4;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }

    public function getChpsSuppDesc3(): ?RefChpsSuppScenarioExpo
    {
        return $this->chpsSuppDesc3;
    }

    public function setChpsSuppDesc3(?RefChpsSuppScenarioExpo $chpsSuppDesc3): self
    {
        $this->chpsSuppDesc3 = $chpsSuppDesc3;

        return $this;
    }

    public function getChpsSuppDesc1(): ?RefChpsSuppScenarioExpo
    {
        return $this->chpsSuppDesc1;
    }

    public function setChpsSuppDesc1(?RefChpsSuppScenarioExpo $chpsSuppDesc1): self
    {
        $this->chpsSuppDesc1 = $chpsSuppDesc1;

        return $this;
    }

    public function getChpsSuppDesc4(): ?RefChpsSuppScenarioExpo
    {
        return $this->chpsSuppDesc4;
    }

    public function setChpsSuppDesc4(?RefChpsSuppScenarioExpo $chpsSuppDesc4): self
    {
        $this->chpsSuppDesc4 = $chpsSuppDesc4;

        return $this;
    }

    public function getChpsSuppDesc2(): ?RefChpsSuppScenarioExpo
    {
        return $this->chpsSuppDesc2;
    }

    public function setChpsSuppDesc2(?RefChpsSuppScenarioExpo $chpsSuppDesc2): self
    {
        $this->chpsSuppDesc2 = $chpsSuppDesc2;

        return $this;
    }


}
