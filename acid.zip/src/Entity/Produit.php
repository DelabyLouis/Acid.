<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Table(name: 'produit')]
#[ORM\Index(name: 'fk_fournisseur', columns: ['FOURNISSEUR'])]
#[ORM\Index(name: 'fk_produit_categorie', columns: ['NUM_CATEGORIE'])]
#[ORM\Entity(repositoryClass: \App\Repository\ProduitRepository::class)]
class Produit
{
    const NUM_ITEMS = 50;

    #[ORM\Column(name: 'ID_PRODUIT', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idProduit;

    #[ORM\Column(name: 'NOM_PRODUIT_COMMERCIAL', type: 'string', length: 255, nullable: false)]
    private readonly string $nomProduitCommercial;

    #[ORM\ManyToOne(targetEntity: Categorie::class)]
    #[ORM\JoinColumn(name: "NUM_CATEGORIE", referencedColumnName: "ID_CATEGORIE")]
    private ?Categorie $numCategorie;

    #[ORM\Column(name: 'DATE_MAJ', type: 'datetime', nullable: true)]
    private ?\DateTime $updatedAt = null;

    #[ORM\Column(name: 'DATE_DONNEES_SOURCES', type: 'date', nullable: true)]
    private ?\DateTime $dateDonneesSources = null;

    #[ORM\Column(name: 'VISIBLE', type: 'integer', nullable: true)]
    private ?int $visible = null;

    #[ORM\Column(name: 'NUM_TYPE', type: 'integer', nullable: true)]
    private ?int $numType = null;

    #[ORM\Column(name: 'NOM_SOCIETE', type: 'string', length: 200, nullable: true)]
    private ?string $nomSociete = null;

    #[ORM\Column(name: 'NUM_URGENCE1', type: 'string', length: 80, nullable: true)]
    private ?string $numUrgence1 = null;

    #[ORM\Column(name: 'NUM_URGENCE2', type: 'string', length: 80, nullable: true)]
    private ?string $numUrgence2 = null;

    #[ORM\Column(name: 'NUM_URGENCE3', type: 'string', length: 80, nullable: true)]
    private ?string $numUrgence3 = null;

    #[ORM\Column(name: 'DOMAINE_APPLI', type: 'string', length: 200, nullable: true)]
    private ?string $domaineAppli = null;

    #[ORM\Column(name: 'CONDITIONNEMENT', type: 'string', length: 200, nullable: true)]
    private ?string $conditionnement = null;

    #[ORM\Column(name: 'MISE_EN_OEUVRE', type: 'text', length: 0, nullable: true)]
    private ?string $miseEnOeuvre = null;

    #[ORM\Column(name: 'SITE_UTILISATEUR', type: 'text', length: 0, nullable: true)]
    private ?string $siteUtilisateur = null;

    #[ORM\Column(name: 'MORTEL', type: 'integer', nullable: true)]
    private ?int $mortel = null;

    /*#[ORM\JoinColumn(name: 'SITE_UTILISATEUR', referencedColumnName: 'id')]
    #[ORM\ManyToOne(targetEntity: Sites::class)]
    private readonly \App\Entity\Sites $siteUtilisateur;*/

    #[ORM\JoinColumn(name: 'FOURNISSEUR', referencedColumnName: 'ID')]
    #[ORM\ManyToOne(targetEntity: RefFournisseur::class)]
    private readonly \App\Entity\RefFournisseur $fournisseur;

    #[ORM\Column(
        name: 'created_at',
        type: 'datetime',
        nullable: false
    )]
    private ?\DateTime $createdAt = null;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class)]
    #[ORM\JoinColumn(name: "updated_by", referencedColumnName: "id")]
    private ?Utilisateur $updatedBy;


    public function getIdProduit(): ?int
    {
        return $this->idProduit;
    }

    public function getNomProduitCommercial(): ?string
    {
        return $this->nomProduitCommercial;
    }

    public function setNomProduitCommercial(string $nomProduitCommercial): self
    {
        $this->nomProduitCommercial = $nomProduitCommercial;

        return $this;
    }

    public function getNumCategorie(): ?Categorie
    {
        return $this->numCategorie;
    }

    public function setNumCategorie(?Categorie $numCategorie): self
    {
        $this->numCategorie = $numCategorie;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getDateDonneesSources(): ?\DateTimeInterface
    {
        return $this->dateDonneesSources;
    }

    public function setDateDonneesSources(?\DateTimeInterface $dateDonneesSources): self
    {
        $this->dateDonneesSources = $dateDonneesSources;

        return $this;
    }

    public function getVisible(): ?int
    {
        return $this->visible;
    }

    public function setVisible(?int $visible): self
    {
        $this->visible = $visible;

        return $this;
    }

    public function getNumType(): ?int
    {
        return $this->numType;
    }

    public function setNumType(?int $numType): self
    {
        $this->numType = $numType;

        return $this;
    }

    public function getNomSociete(): ?string
    {
        return $this->nomSociete;
    }

    public function setNomSociete(?string $nomSociete): self
    {
        $this->nomSociete = $nomSociete;

        return $this;
    }

    public function getNumUrgence1(): ?string
    {
        return $this->numUrgence1;
    }

    public function setNumUrgence1(?string $numUrgence1): self
    {
        $this->numUrgence1 = $numUrgence1;

        return $this;
    }

    public function getNumUrgence2(): ?string
    {
        return $this->numUrgence2;
    }

    public function setNumUrgence2(?string $numUrgence2): self
    {
        $this->numUrgence2 = $numUrgence2;

        return $this;
    }

    public function getNumUrgence3(): ?string
    {
        return $this->numUrgence3;
    }

    public function setNumUrgence3(?string $numUrgence3): self
    {
        $this->numUrgence3 = $numUrgence3;

        return $this;
    }

    public function getDomaineAppli(): ?string
    {
        return $this->domaineAppli;
    }

    public function setDomaineAppli(?string $domaineAppli): self
    {
        $this->domaineAppli = $domaineAppli;

        return $this;
    }

    public function getConditionnement(): ?string
    {
        return $this->conditionnement;
    }

    public function setConditionnement(?string $conditionnement): self
    {
        $this->conditionnement = $conditionnement;

        return $this;
    }

    public function getMiseEnOeuvre(): ?string
    {
        return $this->miseEnOeuvre;
    }

    public function setMiseEnOeuvre(?string $miseEnOeuvre): self
    {
        $this->miseEnOeuvre = $miseEnOeuvre;

        return $this;
    }

    public function getMortel(): ?int
    {
        return $this->mortel;
    }

    public function setMortel(?int $mortel): self
    {
        $this->mortel = $mortel;

        return $this;
    }

    public function getSiteUtilisateur(): ?string
    {
        return $this->siteUtilisateur;
    }

    public function setSiteUtilisateur(?string $siteUtilisateur): self
    {
        $this->siteUtilisateur = $siteUtilisateur;

        return $this;
    }

    public function getFournisseur(): ?RefFournisseur
    {
        return $this->fournisseur;
    }

    public function setFournisseur(?RefFournisseur $fournisseur): self
    {
        $this->fournisseur = $fournisseur;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedBy(): ?Utilisateur
    {
        return $this->updatedBy;
    }

    public function setUpdatedBy(?Utilisateur $updatedBy): self
    {
        $this->updatedBy = $updatedBy;

        return $this;
    }
}
