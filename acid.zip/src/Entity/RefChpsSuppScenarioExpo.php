<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RefChpsSuppScenarioExpo
 */
#[ORM\Table(name: 'ref_chps_supp_scenario_expo')]
#[ORM\Entity]
class RefChpsSuppScenarioExpo
{
    #[ORM\Column(name: 'ID_REF_CHPS_SUPP_SCENARIO_EXPO', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idRefChpsSuppScenarioExpo;

    #[ORM\Column(name: 'VISIBLE', type: 'integer', nullable: true)]
    private ?int $visible = null;

    #[ORM\Column(name: 'LIBELLE', type: 'string', length: 200, nullable: true)]
    private ?string $libelle = null;

    public function getIdRefChpsSuppScenarioExpo(): ?int
    {
        return $this->idRefChpsSuppScenarioExpo;
    }

    public function getVisible(): ?int
    {
        return $this->visible;
    }

    public function setVisible(?int $visible): self
    {
        $this->visible = $visible;

        return $this;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(?string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }


}
