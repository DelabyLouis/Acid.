<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * LibellesAppli
 */
#[ORM\Table(name: 'libelles_appli')]
#[ORM\Entity]
class LibellesAppli
{
    #[ORM\Column(name: 'LIBELLE', type: 'string', length: 200, nullable: true)]
    private ?string $libelle = null;

    #[ORM\Column(name: 'DESCRIPTION', type: 'string', length: 2000, nullable: true)]
    private ?string $description = null;

    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $id;

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(?string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(?string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }


}
