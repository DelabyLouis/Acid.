<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * StabiliteReactivite
 */
#[ORM\Table(name: 'stabilite_reactivite')]
#[ORM\Index(name: 'stabilite_reactivite_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class StabiliteReactivite
{
    #[ORM\Column(name: 'ID_STABILITE_REACTIVITE', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idStabiliteReactivite;

    #[ORM\Column(name: 'STABILITE_CHIMIQUE', type: 'text', length: 0, nullable: true)]
    private ?string $stabiliteChimique = null;

    #[ORM\Column(name: 'CONDITIONS_A_EVITER', type: 'text', length: 0, nullable: true)]
    private ?string $conditionsAEviter = null;

    #[ORM\Column(name: 'PDT_DECOMPOSITION_DANGEREUX', type: 'text', length: 0, nullable: true)]
    private ?string $pdtDecompositionDangereux = null;

    #[ORM\Column(name: 'REACTIVITE', type: 'text', length: 0, nullable: true)]
    private ?string $reactivite = null;

    #[ORM\Column(name: 'REACTION_DANGEREUSE', type: 'text', length: 0, nullable: true)]
    private ?string $reactionDangereuse = null;

    #[ORM\Column(name: 'MATIERES_INCOMPATIBLES', type: 'text', length: 0, nullable: true)]
    private ?string $matieresIncompatibles = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdStabiliteReactivite(): ?int
    {
        return $this->idStabiliteReactivite;
    }

    public function getStabiliteChimique(): ?string
    {
        return $this->stabiliteChimique;
    }

    public function setStabiliteChimique(?string $stabiliteChimique): self
    {
        $this->stabiliteChimique = $stabiliteChimique;

        return $this;
    }

    public function getConditionsAEviter(): ?string
    {
        return $this->conditionsAEviter;
    }

    public function setConditionsAEviter(?string $conditionsAEviter): self
    {
        $this->conditionsAEviter = $conditionsAEviter;

        return $this;
    }

    public function getPdtDecompositionDangereux(): ?string
    {
        return $this->pdtDecompositionDangereux;
    }

    public function setPdtDecompositionDangereux(?string $pdtDecompositionDangereux): self
    {
        $this->pdtDecompositionDangereux = $pdtDecompositionDangereux;

        return $this;
    }

    public function getReactivite(): ?string
    {
        return $this->reactivite;
    }

    public function setReactivite(?string $reactivite): self
    {
        $this->reactivite = $reactivite;

        return $this;
    }

    public function getReactionDangereuse(): ?string
    {
        return $this->reactionDangereuse;
    }

    public function setReactionDangereuse(?string $reactionDangereuse): self
    {
        $this->reactionDangereuse = $reactionDangereuse;

        return $this;
    }

    public function getMatieresIncompatibles(): ?string
    {
        return $this->matieresIncompatibles;
    }

    public function setMatieresIncompatibles(?string $matieresIncompatibles): self
    {
        $this->matieresIncompatibles = $matieresIncompatibles;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
