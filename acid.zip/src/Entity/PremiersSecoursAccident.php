<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * PremiersSecoursAccident
 */
#[ORM\Table(name: 'premiers_secours_accident')]
#[ORM\Index(name: 'premiers_secours_accident_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class PremiersSecoursAccident
{
    #[ORM\Column(name: 'ID_PREMIERS_SECOURS', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idPremiersSecours;

    #[ORM\Column(name: 'CONTACT_PEAU', type: 'text', length: 0, nullable: true)]
    private ?string $contactPeau = null;

    #[ORM\Column(name: 'CONTACT_YEUX', type: 'text', length: 0, nullable: true)]
    private ?string $contactYeux = null;

    #[ORM\Column(name: 'INGESTION', type: 'text', length: 0, nullable: true)]
    private ?string $ingestion = null;

    #[ORM\Column(name: 'INHALATION', type: 'text', length: 0, nullable: true)]
    private ?string $inhalation = null;

    #[ORM\Column(name: 'CONTACT_PEAU_EFFETS', type: 'text', length: 0, nullable: true)]
    private ?string $contactPeauEffets = null;

    #[ORM\Column(name: 'CONTACT_PEAU_SIGNES', type: 'text', length: 0, nullable: true)]
    private ?string $contactPeauSignes = null;

    #[ORM\Column(name: 'CONTACT_YEUX_EFFETS', type: 'text', length: 0, nullable: true)]
    private ?string $contactYeuxEffets = null;

    #[ORM\Column(name: 'CONTACT_YEUX_SIGNES', type: 'text', length: 0, nullable: true)]
    private ?string $contactYeuxSignes = null;

    #[ORM\Column(name: 'INHALATION_EFFETS', type: 'text', length: 0, nullable: true)]
    private ?string $inhalationEffets = null;

    #[ORM\Column(name: 'INHALATION_SIGNES', type: 'text', length: 0, nullable: true)]
    private ?string $inhalationSignes = null;

    #[ORM\Column(name: 'INGESTION_EFFETS', type: 'text', length: 0, nullable: true)]
    private ?string $ingestionEffets = null;

    #[ORM\Column(name: 'INGESTION_SIGNES', type: 'text', length: 0, nullable: true)]
    private ?string $ingestionSignes = null;

    #[ORM\Column(name: 'NOTE_MEDECIN', type: 'text', length: 0, nullable: true)]
    private ?string $noteMedecin = null;

    #[ORM\Column(name: 'TRAITEMENTS', type: 'text', length: 0, nullable: true)]
    private ?string $traitements = null;

    #[ORM\Column(name: 'PROTEC_SAUVETEUR', type: 'text', length: 0, nullable: true)]
    private ?string $protecSauveteur = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdPremiersSecours(): ?int
    {
        return $this->idPremiersSecours;
    }

    public function getContactPeau(): ?string
    {
        return $this->contactPeau;
    }

    public function setContactPeau(?string $contactPeau): self
    {
        $this->contactPeau = $contactPeau;

        return $this;
    }

    public function getContactYeux(): ?string
    {
        return $this->contactYeux;
    }

    public function setContactYeux(?string $contactYeux): self
    {
        $this->contactYeux = $contactYeux;

        return $this;
    }

    public function getIngestion(): ?string
    {
        return $this->ingestion;
    }

    public function setIngestion(?string $ingestion): self
    {
        $this->ingestion = $ingestion;

        return $this;
    }

    public function getInhalation(): ?string
    {
        return $this->inhalation;
    }

    public function setInhalation(?string $inhalation): self
    {
        $this->inhalation = $inhalation;

        return $this;
    }

    public function getContactPeauEffets(): ?string
    {
        return $this->contactPeauEffets;
    }

    public function setContactPeauEffets(?string $contactPeauEffets): self
    {
        $this->contactPeauEffets = $contactPeauEffets;

        return $this;
    }

    public function getContactPeauSignes(): ?string
    {
        return $this->contactPeauSignes;
    }

    public function setContactPeauSignes(?string $contactPeauSignes): self
    {
        $this->contactPeauSignes = $contactPeauSignes;

        return $this;
    }

    public function getContactYeuxEffets(): ?string
    {
        return $this->contactYeuxEffets;
    }

    public function setContactYeuxEffets(?string $contactYeuxEffets): self
    {
        $this->contactYeuxEffets = $contactYeuxEffets;

        return $this;
    }

    public function getContactYeuxSignes(): ?string
    {
        return $this->contactYeuxSignes;
    }

    public function setContactYeuxSignes(?string $contactYeuxSignes): self
    {
        $this->contactYeuxSignes = $contactYeuxSignes;

        return $this;
    }

    public function getInhalationEffets(): ?string
    {
        return $this->inhalationEffets;
    }

    public function setInhalationEffets(?string $inhalationEffets): self
    {
        $this->inhalationEffets = $inhalationEffets;

        return $this;
    }

    public function getInhalationSignes(): ?string
    {
        return $this->inhalationSignes;
    }

    public function setInhalationSignes(?string $inhalationSignes): self
    {
        $this->inhalationSignes = $inhalationSignes;

        return $this;
    }

    public function getIngestionEffets(): ?string
    {
        return $this->ingestionEffets;
    }

    public function setIngestionEffets(?string $ingestionEffets): self
    {
        $this->ingestionEffets = $ingestionEffets;

        return $this;
    }

    public function getIngestionSignes(): ?string
    {
        return $this->ingestionSignes;
    }

    public function setIngestionSignes(?string $ingestionSignes): self
    {
        $this->ingestionSignes = $ingestionSignes;

        return $this;
    }

    public function getNoteMedecin(): ?string
    {
        return $this->noteMedecin;
    }

    public function setNoteMedecin(?string $noteMedecin): self
    {
        $this->noteMedecin = $noteMedecin;

        return $this;
    }

    public function getTraitements(): ?string
    {
        return $this->traitements;
    }

    public function setTraitements(?string $traitements): self
    {
        $this->traitements = $traitements;

        return $this;
    }

    public function getProtecSauveteur(): ?string
    {
        return $this->protecSauveteur;
    }

    public function setProtecSauveteur(?string $protecSauveteur): self
    {
        $this->protecSauveteur = $protecSauveteur;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
