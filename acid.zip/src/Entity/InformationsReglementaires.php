<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * InformationsReglementaires
 */
#[ORM\Table(name: 'informations_reglementaires')]
#[ORM\Index(name: 'informations_reglementair_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class InformationsReglementaires
{
    #[ORM\Column(name: 'ID_INFO_REGLEMENTAIRES', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idInfoReglementaires;

    #[ORM\Column(name: 'DECRETS', type: 'string', length: 500, nullable: true)]
    private ?string $decrets = null;

    #[ORM\Column(name: 'LOIS', type: 'string', length: 2000, nullable: true)]
    private ?string $lois = null;

    #[ORM\Column(name: 'COV', type: 'string', length: 1000, nullable: true)]
    private ?string $cov = null;

    #[ORM\Column(name: 'REGL_NATIONAL', type: 'integer', nullable: true)]
    private ?int $reglNational = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdInfoReglementaires(): ?int
    {
        return $this->idInfoReglementaires;
    }

    public function getDecrets(): ?string
    {
        return $this->decrets;
    }

    public function setDecrets(?string $decrets): self
    {
        $this->decrets = $decrets;

        return $this;
    }

    public function getLois(): ?string
    {
        return $this->lois;
    }

    public function setLois(?string $lois): self
    {
        $this->lois = $lois;

        return $this;
    }

    public function getCov(): ?string
    {
        return $this->cov;
    }

    public function setCov(?string $cov): self
    {
        $this->cov = $cov;

        return $this;
    }

    public function getReglNational(): ?int
    {
        return $this->reglNational;
    }

    public function setReglNational(?int $reglNational): self
    {
        $this->reglNational = $reglNational;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
