<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * NomenclatureDechets
 */
#[ORM\Table(name: 'nomenclature_dechets')]
#[ORM\Entity]
class NomenclatureDechets
{
    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $id;

    #[ORM\Column(name: 'CODE', type: 'string', length: 20, nullable: false)]
    private readonly string $code;

    #[ORM\Column(name: 'LIBELLE', type: 'string', length: 350, nullable: true)]
    private ?string $libelle = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCode(): ?string
    {
        return $this->code;
    }

    public function setCode(string $code): self
    {
        $this->code = $code;

        return $this;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(?string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }


}
