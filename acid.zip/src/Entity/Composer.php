<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * Composer
 */
#[ORM\Table(name: 'composer')]
#[ORM\Index(name: 'composer_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Index(name: 'composer_fk2', columns: ['ID_PRODUIT_EST_COMPOSE'])]
#[ORM\Entity]
class Composer
{
    #[ORM\Column(name: 'ID_COMPOSER', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idComposer;

    #[ORM\Column(name: 'PROPORTION', type: 'string', length: 1000, nullable: true)]
    private ?string $proportion = null;

    #[ORM\Column(name: 'CLASSIFICATION', type: 'string', length: 40, nullable: true)]
    private ?string $classification = null;

    #[ORM\Column(name: 'TYPE', type: 'string', length: 255, nullable: true)]
    private ?string $type = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    #[ORM\JoinColumn(name: 'ID_PRODUIT_EST_COMPOSE', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduitEstCompose;

    public function getIdComposer(): ?int
    {
        return $this->idComposer;
    }

    public function getProportion(): ?string
    {
        return $this->proportion;
    }

    public function setProportion(?string $proportion): self
    {
        $this->proportion = $proportion;

        return $this;
    }

    public function getClassification(): ?string
    {
        return $this->classification;
    }

    public function setClassification(?string $classification): self
    {
        $this->classification = $classification;

        return $this;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }

    public function getIdProduitEstCompose(): ?Produit
    {
        return $this->idProduitEstCompose;
    }

    public function setIdProduitEstCompose(?Produit $idProduitEstCompose): self
    {
        $this->idProduitEstCompose = $idProduitEstCompose;

        return $this;
    }


}
