<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * AutresDonnees
 */
#[ORM\Table(name: 'autres_donnees')]
#[ORM\Index(name: 'AUTRES_DONNEES_FK1', columns: ['ID_PRODUIT'])]
#[ORM\Index(name: 'autres_donnees_fk2', columns: ['ID_COMPOSANT'])]
#[ORM\Entity]
class AutresDonnees
{
    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $id;

    #[ORM\Column(name: 'VISIBLE', type: 'integer', nullable: true)]
    private ?int $visible = null;

    #[ORM\JoinColumn(name: 'ID_COMPOSANT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idComposant;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getVisible(): ?int
    {
        return $this->visible;
    }

    public function setVisible(?int $visible): self
    {
        $this->visible = $visible;

        return $this;
    }

    public function getIdComposant(): ?Produit
    {
        return $this->idComposant;
    }

    public function setIdComposant(?Produit $idComposant): self
    {
        $this->idComposant = $idComposant;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
