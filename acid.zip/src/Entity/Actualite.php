<?php

namespace App\Entity;

use App\Repository\ActualiteRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

#[ORM\Table(name: 'actualite')]
#[ORM\Entity(repositoryClass: ActualiteRepository::class)]
class Actualite implements \Stringable
{
    final public const NUM_ITEMS = 20;
    final public const STATUTS = ['En ligne', 'Hors ligne'];

    #[ORM\Id]
    #[ORM\Column(options: ['unsigned' => true])]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private int $id;

    #[ORM\Column()]
    private \DateTime $createdAt;

    #[ORM\Column(type: 'string', length: 128)]
    #[Assert\NotBlank(message: "Champ obligatoire")]
    private string $titre;

    #[ORM\Column(type: 'text')]
    #[Assert\NotBlank(message: "Champ obligatoire")]
    private string $libelle;

    #[ORM\Column(type: 'string', length: 32)]
    #[Assert\NotBlank(message: "Champ obligatoire")]
    private string $statut;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class, inversedBy: 'access')]
    #[ORM\JoinColumn(name: "utilisateur_id", referencedColumnName: "id")]
    private Utilisateur $utilisateur;

    public function __toString(): string
    {
        return $this->libelle;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getTitre(): ?string
    {
        return $this->titre;
    }

    public function setTitre(string $titre): self
    {
        $this->titre = $titre;

        return $this;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    public function getStatut(): ?string
    {
        return $this->statut;
    }

    public function setStatut(string $statut): self
    {
        $this->statut = $statut;

        return $this;
    }

    public function getUtilisateur(): ?Utilisateur
    {
        return $this->utilisateur;
    }

    public function setUtilisateur(?Utilisateur $utilisateur): self
    {
        $this->utilisateur = $utilisateur;

        return $this;
    }
}