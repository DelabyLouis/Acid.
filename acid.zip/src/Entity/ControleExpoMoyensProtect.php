<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * ControleExpoMoyensProtect
 */
#[ORM\Table(name: 'controle_expo_moyens_protect')]
#[ORM\Index(name: 'controle_expo_moyens_prot_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class ControleExpoMoyensProtect
{
    #[ORM\Column(name: 'ID_EXPO_MOYENS', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idExpoMoyens;

    #[ORM\Column(name: 'DNEL', type: 'text', length: 0, nullable: true)]
    private ?string $dnel = null;

    #[ORM\Column(name: 'PNEC', type: 'text', length: 0, nullable: true)]
    private ?string $pnec = null;

    #[ORM\Column(name: 'PROTECT_RESPIRATOIRE', type: 'text', length: 0, nullable: true)]
    private ?string $protectRespiratoire = null;

    #[ORM\Column(name: 'PROTECT_MAINS', type: 'text', length: 0, nullable: true)]
    private ?string $protectMains = null;

    #[ORM\Column(name: 'PROTECT_FACIALE', type: 'text', length: 0, nullable: true)]
    private ?string $protectFaciale = null;

    #[ORM\Column(name: 'PROTECT_CUTANEE', type: 'text', length: 0, nullable: true)]
    private ?string $protectCutanee = null;

    #[ORM\Column(name: 'MESURES_HYGIENE', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresHygiene = null;

    #[ORM\Column(name: 'EXPO_PRO', type: 'text', length: 0, nullable: true)]
    private ?string $expoPro = null;

    #[ORM\Column(name: 'SURVEILLANCE', type: 'text', length: 0, nullable: true)]
    private ?string $surveillance = null;

    #[ORM\Column(name: 'INGENIERIE', type: 'text', length: 0, nullable: true)]
    private ?string $ingenierie = null;

    #[ORM\Column(name: 'PROTECT_CORPO', type: 'text', length: 0, nullable: true)]
    private ?string $protectCorpo = null;

    #[ORM\Column(name: 'EXPO_ENV', type: 'text', length: 0, nullable: true)]
    private ?string $expoEnv = null;

    #[ORM\Column(name: 'PROTECT_OCULAIRE', type: 'text', length: 0, nullable: true)]
    private ?string $protectOculaire = null;

    #[ORM\Column(name: 'MESURES_HYGIENE_COMMENT', type: 'text', length: 0, nullable: true)]
    private ?string $mesuresHygieneComment = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdExpoMoyens(): ?int
    {
        return $this->idExpoMoyens;
    }

    public function getDnel(): ?string
    {
        return $this->dnel;
    }

    public function setDnel(?string $dnel): self
    {
        $this->dnel = $dnel;

        return $this;
    }

    public function getPnec(): ?string
    {
        return $this->pnec;
    }

    public function setPnec(?string $pnec): self
    {
        $this->pnec = $pnec;

        return $this;
    }

    public function getProtectRespiratoire(): ?string
    {
        return $this->protectRespiratoire;
    }

    public function setProtectRespiratoire(?string $protectRespiratoire): self
    {
        $this->protectRespiratoire = $protectRespiratoire;

        return $this;
    }

    public function getProtectMains(): ?string
    {
        return $this->protectMains;
    }

    public function setProtectMains(?string $protectMains): self
    {
        $this->protectMains = $protectMains;

        return $this;
    }

    public function getProtectFaciale(): ?string
    {
        return $this->protectFaciale;
    }

    public function setProtectFaciale(?string $protectFaciale): self
    {
        $this->protectFaciale = $protectFaciale;

        return $this;
    }

    public function getProtectCutanee(): ?string
    {
        return $this->protectCutanee;
    }

    public function setProtectCutanee(?string $protectCutanee): self
    {
        $this->protectCutanee = $protectCutanee;

        return $this;
    }

    public function getMesuresHygiene(): ?string
    {
        return $this->mesuresHygiene;
    }

    public function setMesuresHygiene(?string $mesuresHygiene): self
    {
        $this->mesuresHygiene = $mesuresHygiene;

        return $this;
    }

    public function getExpoPro(): ?string
    {
        return $this->expoPro;
    }

    public function setExpoPro(?string $expoPro): self
    {
        $this->expoPro = $expoPro;

        return $this;
    }

    public function getSurveillance(): ?string
    {
        return $this->surveillance;
    }

    public function setSurveillance(?string $surveillance): self
    {
        $this->surveillance = $surveillance;

        return $this;
    }

    public function getIngenierie(): ?string
    {
        return $this->ingenierie;
    }

    public function setIngenierie(?string $ingenierie): self
    {
        $this->ingenierie = $ingenierie;

        return $this;
    }

    public function getProtectCorpo(): ?string
    {
        return $this->protectCorpo;
    }

    public function setProtectCorpo(?string $protectCorpo): self
    {
        $this->protectCorpo = $protectCorpo;

        return $this;
    }

    public function getExpoEnv(): ?string
    {
        return $this->expoEnv;
    }

    public function setExpoEnv(?string $expoEnv): self
    {
        $this->expoEnv = $expoEnv;

        return $this;
    }

    public function getProtectOculaire(): ?string
    {
        return $this->protectOculaire;
    }

    public function setProtectOculaire(?string $protectOculaire): self
    {
        $this->protectOculaire = $protectOculaire;

        return $this;
    }

    public function getMesuresHygieneComment(): ?string
    {
        return $this->mesuresHygieneComment;
    }

    public function setMesuresHygieneComment(?string $mesuresHygieneComment): self
    {
        $this->mesuresHygieneComment = $mesuresHygieneComment;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
