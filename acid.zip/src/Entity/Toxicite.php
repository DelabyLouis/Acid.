<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * Toxicite
 */
#[ORM\Table(name: 'toxicite')]
#[ORM\Index(name: 'toxicite_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class Toxicite
{
    #[ORM\Column(name: 'ID_TOXICITE', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idToxicite;

    #[ORM\Column(name: 'TOXICITE_AIGUE_PEAU', type: 'text', length: 0, nullable: true)]
    private ?string $toxiciteAiguePeau = null;

    #[ORM\Column(name: 'TOXICITE_AIGUE_YEUX', type: 'text', length: 0, nullable: true)]
    private ?string $toxiciteAigueYeux = null;

    #[ORM\Column(name: 'TOXICITE_AIGUE_INGESTION', type: 'text', length: 0, nullable: true)]
    private ?string $toxiciteAigueIngestion = null;

    #[ORM\Column(name: 'TOXICITE_AIGUE_INHALATION', type: 'text', length: 0, nullable: true)]
    private ?string $toxiciteAigueInhalation = null;

    #[ORM\Column(name: 'DL50', type: 'text', length: 0, nullable: true)]
    private ?string $dl50 = null;

    #[ORM\Column(name: 'CL50', type: 'text', length: 0, nullable: true)]
    private ?string $cl50 = null;

    #[ORM\Column(name: 'SYMPTOMES_PEAU', type: 'text', length: 0, nullable: true)]
    private ?string $symptomesPeau = null;

    #[ORM\Column(name: 'SYMPTOMES_YEUX', type: 'text', length: 0, nullable: true)]
    private ?string $symptomesYeux = null;

    #[ORM\Column(name: 'SYMPTOMES_INGESTION', type: 'text', length: 0, nullable: true)]
    private ?string $symptomesIngestion = null;

    #[ORM\Column(name: 'SYMPTOMES_INHALATION', type: 'text', length: 0, nullable: true)]
    private ?string $symptomesInhalation = null;

    #[ORM\Column(name: 'EFFETS_EXPO_COURTE_DUREE', type: 'text', length: 0, nullable: true)]
    private ?string $effetsExpoCourteDuree = null;

    #[ORM\Column(name: 'EFFETS_POTENTIELS_IMMEDIATS', type: 'text', length: 0, nullable: true)]
    private ?string $effetsPotentielsImmediats = null;

    #[ORM\Column(name: 'EFFETS_POTENTIELS_DIFFERES', type: 'text', length: 0, nullable: true)]
    private ?string $effetsPotentielsDifferes = null;

    #[ORM\Column(name: 'EXPO_POTENTIELS_IMMEDIATS', type: 'text', length: 0, nullable: true)]
    private ?string $expoPotentielsImmediats = null;

    #[ORM\Column(name: 'EXPO_POTENTIELS_DIFFERES', type: 'text', length: 0, nullable: true)]
    private ?string $expoPotentielsDifferes = null;

    #[ORM\Column(name: 'CONCLUSION', type: 'text', length: 0, nullable: true)]
    private ?string $conclusion = null;

    #[ORM\Column(name: 'GENERALITES', type: 'text', length: 0, nullable: true)]
    private ?string $generalites = null;

    #[ORM\Column(name: 'VOIES_EXPO_PROBABLES', type: 'text', length: 0, nullable: true)]
    private ?string $voiesExpoProbables = null;

    #[ORM\Column(name: 'TERATOGENICITE', type: 'text', length: 0, nullable: true)]
    private ?string $teratogenicite = null;

    #[ORM\Column(name: 'IRRI_CUTANEE_OCULAIRE', type: 'text', length: 0, nullable: true)]
    private ?string $irriCutaneeOculaire = null;

    #[ORM\Column(name: 'SENS_CUTANEE_RESP', type: 'text', length: 0, nullable: true)]
    private ?string $sensCutaneeResp = null;

    #[ORM\Column(name: 'EFFETS_SUBAIGUES', type: 'text', length: 0, nullable: true)]
    private ?string $effetsSubaigues = null;

    #[ORM\Column(name: 'EFFETS_MUTAGENE', type: 'text', length: 0, nullable: true)]
    private ?string $effetsMutagene = null;

    #[ORM\Column(name: 'EFFETS_CANCER', type: 'text', length: 0, nullable: true)]
    private ?string $effetsCancer = null;

    #[ORM\Column(name: 'REPRODUCTION', type: 'text', length: 0, nullable: true)]
    private ?string $reproduction = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdToxicite(): ?int
    {
        return $this->idToxicite;
    }

    public function getToxiciteAiguePeau(): ?string
    {
        return $this->toxiciteAiguePeau;
    }

    public function setToxiciteAiguePeau(?string $toxiciteAiguePeau): self
    {
        $this->toxiciteAiguePeau = $toxiciteAiguePeau;

        return $this;
    }

    public function getToxiciteAigueYeux(): ?string
    {
        return $this->toxiciteAigueYeux;
    }

    public function setToxiciteAigueYeux(?string $toxiciteAigueYeux): self
    {
        $this->toxiciteAigueYeux = $toxiciteAigueYeux;

        return $this;
    }

    public function getToxiciteAigueIngestion(): ?string
    {
        return $this->toxiciteAigueIngestion;
    }

    public function setToxiciteAigueIngestion(?string $toxiciteAigueIngestion): self
    {
        $this->toxiciteAigueIngestion = $toxiciteAigueIngestion;

        return $this;
    }

    public function getToxiciteAigueInhalation(): ?string
    {
        return $this->toxiciteAigueInhalation;
    }

    public function setToxiciteAigueInhalation(?string $toxiciteAigueInhalation): self
    {
        $this->toxiciteAigueInhalation = $toxiciteAigueInhalation;

        return $this;
    }

    public function getDl50(): ?string
    {
        return $this->dl50;
    }

    public function setDl50(?string $dl50): self
    {
        $this->dl50 = $dl50;

        return $this;
    }

    public function getCl50(): ?string
    {
        return $this->cl50;
    }

    public function setCl50(?string $cl50): self
    {
        $this->cl50 = $cl50;

        return $this;
    }

    public function getSymptomesPeau(): ?string
    {
        return $this->symptomesPeau;
    }

    public function setSymptomesPeau(?string $symptomesPeau): self
    {
        $this->symptomesPeau = $symptomesPeau;

        return $this;
    }

    public function getSymptomesYeux(): ?string
    {
        return $this->symptomesYeux;
    }

    public function setSymptomesYeux(?string $symptomesYeux): self
    {
        $this->symptomesYeux = $symptomesYeux;

        return $this;
    }

    public function getSymptomesIngestion(): ?string
    {
        return $this->symptomesIngestion;
    }

    public function setSymptomesIngestion(?string $symptomesIngestion): self
    {
        $this->symptomesIngestion = $symptomesIngestion;

        return $this;
    }

    public function getSymptomesInhalation(): ?string
    {
        return $this->symptomesInhalation;
    }

    public function setSymptomesInhalation(?string $symptomesInhalation): self
    {
        $this->symptomesInhalation = $symptomesInhalation;

        return $this;
    }

    public function getEffetsExpoCourteDuree(): ?string
    {
        return $this->effetsExpoCourteDuree;
    }

    public function setEffetsExpoCourteDuree(?string $effetsExpoCourteDuree): self
    {
        $this->effetsExpoCourteDuree = $effetsExpoCourteDuree;

        return $this;
    }

    public function getEffetsPotentielsImmediats(): ?string
    {
        return $this->effetsPotentielsImmediats;
    }

    public function setEffetsPotentielsImmediats(?string $effetsPotentielsImmediats): self
    {
        $this->effetsPotentielsImmediats = $effetsPotentielsImmediats;

        return $this;
    }

    public function getEffetsPotentielsDifferes(): ?string
    {
        return $this->effetsPotentielsDifferes;
    }

    public function setEffetsPotentielsDifferes(?string $effetsPotentielsDifferes): self
    {
        $this->effetsPotentielsDifferes = $effetsPotentielsDifferes;

        return $this;
    }

    public function getExpoPotentielsImmediats(): ?string
    {
        return $this->expoPotentielsImmediats;
    }

    public function setExpoPotentielsImmediats(?string $expoPotentielsImmediats): self
    {
        $this->expoPotentielsImmediats = $expoPotentielsImmediats;

        return $this;
    }

    public function getExpoPotentielsDifferes(): ?string
    {
        return $this->expoPotentielsDifferes;
    }

    public function setExpoPotentielsDifferes(?string $expoPotentielsDifferes): self
    {
        $this->expoPotentielsDifferes = $expoPotentielsDifferes;

        return $this;
    }

    public function getConclusion(): ?string
    {
        return $this->conclusion;
    }

    public function setConclusion(?string $conclusion): self
    {
        $this->conclusion = $conclusion;

        return $this;
    }

    public function getGeneralites(): ?string
    {
        return $this->generalites;
    }

    public function setGeneralites(?string $generalites): self
    {
        $this->generalites = $generalites;

        return $this;
    }

    public function getVoiesExpoProbables(): ?string
    {
        return $this->voiesExpoProbables;
    }

    public function setVoiesExpoProbables(?string $voiesExpoProbables): self
    {
        $this->voiesExpoProbables = $voiesExpoProbables;

        return $this;
    }

    public function getTeratogenicite(): ?string
    {
        return $this->teratogenicite;
    }

    public function setTeratogenicite(?string $teratogenicite): self
    {
        $this->teratogenicite = $teratogenicite;

        return $this;
    }

    public function getIrriCutaneeOculaire(): ?string
    {
        return $this->irriCutaneeOculaire;
    }

    public function setIrriCutaneeOculaire(?string $irriCutaneeOculaire): self
    {
        $this->irriCutaneeOculaire = $irriCutaneeOculaire;

        return $this;
    }

    public function getSensCutaneeResp(): ?string
    {
        return $this->sensCutaneeResp;
    }

    public function setSensCutaneeResp(?string $sensCutaneeResp): self
    {
        $this->sensCutaneeResp = $sensCutaneeResp;

        return $this;
    }

    public function getEffetsSubaigues(): ?string
    {
        return $this->effetsSubaigues;
    }

    public function setEffetsSubaigues(?string $effetsSubaigues): self
    {
        $this->effetsSubaigues = $effetsSubaigues;

        return $this;
    }

    public function getEffetsMutagene(): ?string
    {
        return $this->effetsMutagene;
    }

    public function setEffetsMutagene(?string $effetsMutagene): self
    {
        $this->effetsMutagene = $effetsMutagene;

        return $this;
    }

    public function getEffetsCancer(): ?string
    {
        return $this->effetsCancer;
    }

    public function setEffetsCancer(?string $effetsCancer): self
    {
        $this->effetsCancer = $effetsCancer;

        return $this;
    }

    public function getReproduction(): ?string
    {
        return $this->reproduction;
    }

    public function setReproduction(?string $reproduction): self
    {
        $this->reproduction = $reproduction;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
