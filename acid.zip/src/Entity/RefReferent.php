<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \App\Repository\RefReferentRepository::class)]
#[ORM\Table(name: 'ref_referent')]
class RefReferent
{

    const NUM_ITEMS = 30;

    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $id;

    #[ORM\Column(name: 'NOM', type: 'string', length: 100, nullable: true)]
    private ?string $nom = null;

    #[ORM\Column(name: 'Prenom', type: 'string', length: 100, nullable: true)]
    private ?string $prenom = null;

    #[ORM\Column(name: 'Organisme_beneficiaire', type: 'string', length: 200, nullable: true)]
    private ?string $organismeBeneficiaire = null;

    #[ORM\Column(name: 'adresse', type: 'string', length: 200, nullable: true)]
    private ?string $adresse = null;

    #[ORM\Column(name: 'cp', type: 'string', length: 45, nullable: true)]
    private ?string $cp = null;

    #[ORM\Column(name: 'ville', type: 'string', length: 100, nullable: true)]
    private ?string $ville = null;

    #[ORM\Column(name: 'mobile', type: 'string', length: 45, nullable: true)]
    private ?string $mobile = null;

    #[ORM\Column(name: 'fixe', type: 'string', length: 45, nullable: true)]
    private ?string $fixe = null;

    #[ORM\Column(name: 'mail', type: 'string', length: 100, nullable: true)]
    private ?string $mail = null;

    #[ORM\Column]
    private $actif = NULL;

    #[ORM\Column(
        name: 'created_at',
        type: 'datetime',
        nullable: false
    )]
    private ?\DateTime $createdAt = null;

    #[ORM\Column(
        name: 'updated_at',
        type: 'datetime',
        nullable: true
    )]
    private ?\DateTime $updatedAt = null;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class)]
    #[ORM\JoinColumn(name: "updated_by", referencedColumnName: "id")]
    private ?Utilisateur $updatedBy;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(?string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(?string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getOrganismeBeneficiaire(): ?string
    {
        return $this->organismeBeneficiaire;
    }

    public function setOrganismeBeneficiaire(?string $organismeBeneficiaire): self
    {
        $this->organismeBeneficiaire = $organismeBeneficiaire;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(?string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getCp(): ?string
    {
        return $this->cp;
    }

    public function setCp(?string $cp): self
    {
        $this->cp = $cp;

        return $this;
    }

    public function getVille(): ?string
    {
        return $this->ville;
    }

    public function setVille(?string $ville): self
    {
        $this->ville = $ville;

        return $this;
    }

    public function getMobile(): ?string
    {
        return $this->mobile;
    }

    public function setMobile(?string $mobile): self
    {
        $this->mobile = $mobile;

        return $this;
    }

    public function getFixe(): ?string
    {
        return $this->fixe;
    }

    public function setFixe(?string $fixe): self
    {
        $this->fixe = $fixe;

        return $this;
    }

    public function getMail(): ?string
    {
        return $this->mail;
    }

    public function setMail(?string $mail): self
    {
        $this->mail = $mail;

        return $this;
    }



    /**
     * Get the value of actif
     */
    public function getActif()
    {
        return $this->actif;
    }

    /**
     * Set the value of actif
     *
     * @return  self
     */
    public function setActif($actif)
    {
        $this->actif = $actif;

        return $this;
    }

    /**
     * Get the value of createdAt
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set the value of createdAt
     *
     * @return  self
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get the value of updatedAt
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set the value of updatedAt
     *
     * @return  self
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get the value of updatedBy
     */
    public function getUpdatedBy()
    {
        return $this->updatedBy;
    }

    /**
     * Set the value of updatedBy
     *
     * @return  self
     */
    public function setUpdatedBy($updatedBy)
    {
        $this->updatedBy = $updatedBy;

        return $this;
    }
}
