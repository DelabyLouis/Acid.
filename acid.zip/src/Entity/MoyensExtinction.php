<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: \App\Repository\MoyensExtinctionRepository::class)]
#[ORM\Table(name: 'moyens_extinction')]

class MoyensExtinction
{
    const NUM_ITEMS = 20;

    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private int $id;

    #[ORM\Column(name: 'LIBELLE', type: 'string', length: 80, nullable: false)]
    private string $libelle;

    #[ORM\Column]
    private $actif = NULL;

    #[ORM\Column(
        name: 'created_at',
        type: 'datetime',
        nullable: false
    )]
    private ?\DateTime $createdAt = null;

    #[ORM\Column(
        name: 'updated_at',
        type: 'datetime',
        nullable: true
    )]
    private ?\DateTime $updatedAt = null;

    #[ORM\ManyToOne(targetEntity: Utilisateur::class)]
    #[ORM\JoinColumn(name: "updated_by", referencedColumnName: "id")]
    private ?Utilisateur $updatedBy;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getLibelle(): ?string
    {
        return $this->libelle;
    }

    public function setLibelle(string $libelle): self
    {
        $this->libelle = $libelle;

        return $this;
    }

    /**
     * Get the value of actif
     */
    public function getActif()
    {
        return $this->actif;
    }

    /**
     * Set the value of actif
     *
     * @return  self
     */
    public function setActif($actif)
    {
        $this->actif = $actif;

        return $this;
    }

    public function getCreatedAt(): ?\DateTimeInterface
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTimeInterface $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): ?\DateTimeInterface
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?\DateTimeInterface $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get the value of updatedBy
     */
    public function getUpdatedBy(): ?Utilisateur
    {
        return $this->updatedBy;
    }

    /**
     * Set the value of updatedBy
     *
     * @return  self
     */
    public function setUpdatedBy(?Utilisateur $updatedBy): self
    {
        $this->updatedBy = $updatedBy;

        return $this;
    }
}
