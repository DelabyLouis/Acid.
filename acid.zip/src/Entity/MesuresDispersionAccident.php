<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * MesuresDispersionAccident
 */
#[ORM\Table(name: 'mesures_dispersion_accident')]
#[ORM\Index(name: 'mesures_dispersion_accide_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class MesuresDispersionAccident
{
    #[ORM\Column(name: 'ID_MESURES_DISPERSION', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idMesuresDispersion;

    #[ORM\Column(name: 'PRECAUTIONS_INDIVIDUELLES', type: 'text', length: 0, nullable: true)]
    private ?string $precautionsIndividuelles = null;

    #[ORM\Column(name: 'PETIT_DEVERSEMENT', type: 'text', length: 0, nullable: true)]
    private ?string $petitDeversement = null;

    #[ORM\Column(name: 'REF_AUTRES', type: 'text', length: 0, nullable: true)]
    private ?string $refAutres = null;

    #[ORM\Column(name: 'PRECAUTIONS_ENVIRONNEMENT', type: 'text', length: 0, nullable: true)]
    private ?string $precautionsEnvironnement = null;

    #[ORM\Column(name: 'PRECAUTIONS_INDIV_AUTRES', type: 'text', length: 0, nullable: true)]
    private ?string $precautionsIndivAutres = null;

    #[ORM\Column(name: 'GRAND_DEVERSEMENT', type: 'text', length: 0, nullable: true)]
    private ?string $grandDeversement = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdMesuresDispersion(): ?int
    {
        return $this->idMesuresDispersion;
    }

    public function getPrecautionsIndividuelles(): ?string
    {
        return $this->precautionsIndividuelles;
    }

    public function setPrecautionsIndividuelles(?string $precautionsIndividuelles): self
    {
        $this->precautionsIndividuelles = $precautionsIndividuelles;

        return $this;
    }

    public function getPetitDeversement(): ?string
    {
        return $this->petitDeversement;
    }

    public function setPetitDeversement(?string $petitDeversement): self
    {
        $this->petitDeversement = $petitDeversement;

        return $this;
    }

    public function getRefAutres(): ?string
    {
        return $this->refAutres;
    }

    public function setRefAutres(?string $refAutres): self
    {
        $this->refAutres = $refAutres;

        return $this;
    }

    public function getPrecautionsEnvironnement(): ?string
    {
        return $this->precautionsEnvironnement;
    }

    public function setPrecautionsEnvironnement(?string $precautionsEnvironnement): self
    {
        $this->precautionsEnvironnement = $precautionsEnvironnement;

        return $this;
    }

    public function getPrecautionsIndivAutres(): ?string
    {
        return $this->precautionsIndivAutres;
    }

    public function setPrecautionsIndivAutres(?string $precautionsIndivAutres): self
    {
        $this->precautionsIndivAutres = $precautionsIndivAutres;

        return $this;
    }

    public function getGrandDeversement(): ?string
    {
        return $this->grandDeversement;
    }

    public function setGrandDeversement(?string $grandDeversement): self
    {
        $this->grandDeversement = $grandDeversement;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
