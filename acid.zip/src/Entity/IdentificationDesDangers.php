<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * IdentificationDesDangers
 */
#[ORM\Table(name: 'identification_des_dangers')]
#[ORM\Index(name: 'identification_des_danger_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class IdentificationDesDangers
{
    #[ORM\Column(name: 'ID_DANGERS', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idDangers;

    #[ORM\Column(name: 'COMBUSTIBLE', type: 'text', length: 0, nullable: true)]
    private ?string $combustible = null;

    #[ORM\Column(name: 'COMBURANT', type: 'string', length: 100, nullable: true)]
    private ?string $comburant = null;

    #[ORM\Column(name: 'INFLAMMABLE', type: 'string', length: 255, nullable: true)]
    private ?string $inflammable = null;

    #[ORM\Column(name: 'TOXIQUE', type: 'string', length: 100, nullable: true)]
    private ?string $toxique = null;

    #[ORM\Column(name: 'EXPLOSIF', type: 'string', length: 255, nullable: true)]
    private ?string $explosif = null;

    #[ORM\Column(name: 'NOCIF', type: 'string', length: 255, nullable: true)]
    private ?string $nocif = null;

    #[ORM\Column(name: 'CORROSIF', type: 'string', length: 255, nullable: true)]
    private ?string $corrosif = null;

    #[ORM\Column(name: 'IRRITANT', type: 'string', length: 255, nullable: true)]
    private ?string $irritant = null;

    #[ORM\Column(name: 'SENSIBILISANT', type: 'string', length: 100, nullable: true)]
    private ?string $sensibilisant = null;

    #[ORM\Column(name: 'DANGEREUX_ENVIRONNEMENT', type: 'string', length: 255, nullable: true)]
    private ?string $dangereuxEnvironnement = null;

    #[ORM\Column(name: 'CANCEROGENE', type: 'string', length: 100, nullable: true)]
    private ?string $cancerogene = null;

    #[ORM\Column(name: 'MUTAGENE', type: 'string', length: 100, nullable: true)]
    private ?string $mutagene = null;

    #[ORM\Column(name: 'TOXIQUE_REPRODUCTION', type: 'string', length: 100, nullable: true)]
    private ?string $toxiqueReproduction = null;

    #[ORM\Column(name: 'DANGEREUX', type: 'integer', nullable: false)]
    private string|int $dangereux = '0';

    #[ORM\Column(name: 'SYMBOLE_DANGER_ANCIEN', type: 'string', length: 600, nullable: true)]
    private ?string $symboleDangerAncien = null;

    #[ORM\Column(name: 'PHRASES_R', type: 'text', length: 0, nullable: true)]
    private ?string $phrasesR = null;

    #[ORM\Column(name: 'PHRASES_H', type: 'text', length: 0, nullable: true)]
    private ?string $phrasesH = null;

    #[ORM\Column(name: 'PHRASES_S', type: 'text', length: 0, nullable: true)]
    private ?string $phrasesS = null;

    #[ORM\Column(name: 'PHRASES_P', type: 'text', length: 0, nullable: true)]
    private ?string $phrasesP = null;

    #[ORM\Column(name: 'INGREDIENTS_DANGEREUX', type: 'text', length: 0, nullable: true)]
    private ?string $ingredientsDangereux = null;

    #[ORM\Column(name: 'ELEMENTS_SUPP', type: 'text', length: 0, nullable: true)]
    private ?string $elementsSupp = null;

    #[ORM\Column(name: 'FERMETURE_ENFANT', type: 'integer', nullable: true)]
    private ?int $fermetureEnfant = null;

    #[ORM\Column(name: 'AUTRES_DANGERS', type: 'text', length: 0, nullable: true)]
    private ?string $autresDangers = null;

    #[ORM\Column(name: 'DEFINITION', type: 'string', length: 40, nullable: false)]
    private readonly string $definition;

    #[ORM\Column(name: 'SYMBOLE_DANGER_NOUVEAU', type: 'string', length: 600, nullable: true)]
    private ?string $symboleDangerNouveau = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdDangers(): ?int
    {
        return $this->idDangers;
    }

    public function getCombustible(): ?string
    {
        return $this->combustible;
    }

    public function setCombustible(?string $combustible): self
    {
        $this->combustible = $combustible;

        return $this;
    }

    public function getComburant(): ?string
    {
        return $this->comburant;
    }

    public function setComburant(?string $comburant): self
    {
        $this->comburant = $comburant;

        return $this;
    }

    public function getInflammable(): ?string
    {
        return $this->inflammable;
    }

    public function setInflammable(?string $inflammable): self
    {
        $this->inflammable = $inflammable;

        return $this;
    }

    public function getToxique(): ?string
    {
        return $this->toxique;
    }

    public function setToxique(?string $toxique): self
    {
        $this->toxique = $toxique;

        return $this;
    }

    public function getExplosif(): ?string
    {
        return $this->explosif;
    }

    public function setExplosif(?string $explosif): self
    {
        $this->explosif = $explosif;

        return $this;
    }

    public function getNocif(): ?string
    {
        return $this->nocif;
    }

    public function setNocif(?string $nocif): self
    {
        $this->nocif = $nocif;

        return $this;
    }

    public function getCorrosif(): ?string
    {
        return $this->corrosif;
    }

    public function setCorrosif(?string $corrosif): self
    {
        $this->corrosif = $corrosif;

        return $this;
    }

    public function getIrritant(): ?string
    {
        return $this->irritant;
    }

    public function setIrritant(?string $irritant): self
    {
        $this->irritant = $irritant;

        return $this;
    }

    public function getSensibilisant(): ?string
    {
        return $this->sensibilisant;
    }

    public function setSensibilisant(?string $sensibilisant): self
    {
        $this->sensibilisant = $sensibilisant;

        return $this;
    }

    public function getDangereuxEnvironnement(): ?string
    {
        return $this->dangereuxEnvironnement;
    }

    public function setDangereuxEnvironnement(?string $dangereuxEnvironnement): self
    {
        $this->dangereuxEnvironnement = $dangereuxEnvironnement;

        return $this;
    }

    public function getCancerogene(): ?string
    {
        return $this->cancerogene;
    }

    public function setCancerogene(?string $cancerogene): self
    {
        $this->cancerogene = $cancerogene;

        return $this;
    }

    public function getMutagene(): ?string
    {
        return $this->mutagene;
    }

    public function setMutagene(?string $mutagene): self
    {
        $this->mutagene = $mutagene;

        return $this;
    }

    public function getToxiqueReproduction(): ?string
    {
        return $this->toxiqueReproduction;
    }

    public function setToxiqueReproduction(?string $toxiqueReproduction): self
    {
        $this->toxiqueReproduction = $toxiqueReproduction;

        return $this;
    }

    public function getDangereux(): ?int
    {
        return $this->dangereux;
    }

    public function setDangereux(int $dangereux): self
    {
        $this->dangereux = $dangereux;

        return $this;
    }

    public function getSymboleDangerAncien(): ?string
    {
        return $this->symboleDangerAncien;
    }

    public function setSymboleDangerAncien(?string $symboleDangerAncien): self
    {
        $this->symboleDangerAncien = $symboleDangerAncien;

        return $this;
    }

    public function getPhrasesR(): ?string
    {
        return $this->phrasesR;
    }

    public function setPhrasesR(?string $phrasesR): self
    {
        $this->phrasesR = $phrasesR;

        return $this;
    }

    public function getPhrasesH(): ?string
    {
        return $this->phrasesH;
    }

    public function setPhrasesH(?string $phrasesH): self
    {
        $this->phrasesH = $phrasesH;

        return $this;
    }

    public function getPhrasesS(): ?string
    {
        return $this->phrasesS;
    }

    public function setPhrasesS(?string $phrasesS): self
    {
        $this->phrasesS = $phrasesS;

        return $this;
    }

    public function getPhrasesP(): ?string
    {
        return $this->phrasesP;
    }

    public function setPhrasesP(?string $phrasesP): self
    {
        $this->phrasesP = $phrasesP;

        return $this;
    }

    public function getIngredientsDangereux(): ?string
    {
        return $this->ingredientsDangereux;
    }

    public function setIngredientsDangereux(?string $ingredientsDangereux): self
    {
        $this->ingredientsDangereux = $ingredientsDangereux;

        return $this;
    }

    public function getElementsSupp(): ?string
    {
        return $this->elementsSupp;
    }

    public function setElementsSupp(?string $elementsSupp): self
    {
        $this->elementsSupp = $elementsSupp;

        return $this;
    }

    public function getFermetureEnfant(): ?int
    {
        return $this->fermetureEnfant;
    }

    public function setFermetureEnfant(?int $fermetureEnfant): self
    {
        $this->fermetureEnfant = $fermetureEnfant;

        return $this;
    }

    public function getAutresDangers(): ?string
    {
        return $this->autresDangers;
    }

    public function setAutresDangers(?string $autresDangers): self
    {
        $this->autresDangers = $autresDangers;

        return $this;
    }

    public function getDefinition(): ?string
    {
        return $this->definition;
    }

    public function setDefinition(string $definition): self
    {
        $this->definition = $definition;

        return $this;
    }

    public function getSymboleDangerNouveau(): ?string
    {
        return $this->symboleDangerNouveau;
    }

    public function setSymboleDangerNouveau(?string $symboleDangerNouveau): self
    {
        $this->symboleDangerNouveau = $symboleDangerNouveau;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
