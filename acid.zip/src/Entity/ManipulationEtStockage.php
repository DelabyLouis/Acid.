<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * ManipulationEtStockage
 */
#[ORM\Table(name: 'manipulation_et_stockage')]
#[ORM\Index(name: 'manipulation_et_stockage_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class ManipulationEtStockage
{
    #[ORM\Column(name: 'ID_MANIP_STOCK', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idManipStock;

    #[ORM\Column(name: 'CONSEILS_HYGIENE', type: 'string', length: 3000, nullable: true)]
    private ?string $conseilsHygiene = null;

    #[ORM\Column(name: 'MESURES_PROTECTRICES_MANIP', type: 'string', length: 3000, nullable: true)]
    private ?string $mesuresProtectricesManip = null;

    #[ORM\Column(name: 'STOCKAGE', type: 'string', length: 3000, nullable: true)]
    private ?string $stockage = null;

    #[ORM\Column(name: 'RECOMMANDATIONS', type: 'string', length: 3000, nullable: true)]
    private ?string $recommandations = null;

    #[ORM\Column(name: 'SOLUTIONS_SPECIFIQUES', type: 'string', length: 3000, nullable: true)]
    private ?string $solutionsSpecifiques = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdManipStock(): ?int
    {
        return $this->idManipStock;
    }

    public function getConseilsHygiene(): ?string
    {
        return $this->conseilsHygiene;
    }

    public function setConseilsHygiene(?string $conseilsHygiene): self
    {
        $this->conseilsHygiene = $conseilsHygiene;

        return $this;
    }

    public function getMesuresProtectricesManip(): ?string
    {
        return $this->mesuresProtectricesManip;
    }

    public function setMesuresProtectricesManip(?string $mesuresProtectricesManip): self
    {
        $this->mesuresProtectricesManip = $mesuresProtectricesManip;

        return $this;
    }

    public function getStockage(): ?string
    {
        return $this->stockage;
    }

    public function setStockage(?string $stockage): self
    {
        $this->stockage = $stockage;

        return $this;
    }

    public function getRecommandations(): ?string
    {
        return $this->recommandations;
    }

    public function setRecommandations(?string $recommandations): self
    {
        $this->recommandations = $recommandations;

        return $this;
    }

    public function getSolutionsSpecifiques(): ?string
    {
        return $this->solutionsSpecifiques;
    }

    public function setSolutionsSpecifiques(?string $solutionsSpecifiques): self
    {
        $this->solutionsSpecifiques = $solutionsSpecifiques;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
