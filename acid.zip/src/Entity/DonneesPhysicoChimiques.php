<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * DonneesPhysicoChimiques
 */
#[ORM\Table(name: 'donnees_physico_chimiques')]
#[ORM\Index(name: 'donnees_physico_chimiques_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class DonneesPhysicoChimiques
{
    #[ORM\Column(name: 'ID_PHYSICO_CHIMIQUES', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idPhysicoChimiques;

    #[ORM\Column(name: 'MASSE_MOLAIRE', type: 'string', length: 100, nullable: true)]
    private ?string $masseMolaire = null;

    #[ORM\Column(name: 'TEMPERATURE_EBULLITION', type: 'string', length: 100, nullable: true)]
    private ?string $temperatureEbullition = null;

    #[ORM\Column(name: 'TEMPERATURE_FUSION', type: 'string', length: 100, nullable: true)]
    private ?string $temperatureFusion = null;

    #[ORM\Column(name: 'TEMPERATURE_AUTOINFLAMMATION', type: 'string', length: 100, nullable: true)]
    private ?string $temperatureAutoinflammation = null;

    #[ORM\Column(name: 'ETAT_PHYSIQUE', type: 'string', length: 100, nullable: true)]
    private ?string $etatPhysique = null;

    #[ORM\Column(name: 'FORME', type: 'string', length: 100, nullable: true)]
    private ?string $forme = null;

    #[ORM\Column(name: 'COULEUR', type: 'string', length: 100, nullable: true)]
    private ?string $couleur = null;

    #[ORM\Column(name: 'ODEUR', type: 'string', length: 100, nullable: true)]
    private ?string $odeur = null;

    #[ORM\Column(name: 'PH', type: 'string', length: 50, nullable: true)]
    private ?string $ph = null;

    #[ORM\Column(name: 'POINT_ECLAIR', type: 'string', length: 100, nullable: true)]
    private ?string $pointEclair = null;

    #[ORM\Column(name: 'DENSITE_LIQUIDE', type: 'string', length: 100, nullable: true)]
    private ?string $densiteLiquide = null;

    #[ORM\Column(name: 'DENSITE_SOLIDE', type: 'string', length: 100, nullable: true)]
    private ?string $densiteSolide = null;

    #[ORM\Column(name: 'DENSITE_VAPEUR', type: 'string', length: 100, nullable: true)]
    private ?string $densiteVapeur = null;

    #[ORM\Column(name: 'TENSION_VAPEUR', type: 'string', length: 100, nullable: true)]
    private ?string $tensionVapeur = null;

    #[ORM\Column(name: 'SOLUBILITE_EAU', type: 'string', length: 100, nullable: true)]
    private ?string $solubiliteEau = null;

    #[ORM\Column(name: 'CARACTERISTIQUES_EXPLOSIVITE', type: 'string', length: 100, nullable: true)]
    private ?string $caracteristiquesExplosivite = null;

    #[ORM\Column(name: 'REMARQUE', type: 'string', length: 3000, nullable: true)]
    private ?string $remarque = null;

    #[ORM\Column(name: 'FORMULE_BRUTE', type: 'string', length: 100, nullable: true)]
    private ?string $formuleBrute = null;

    #[ORM\Column(name: 'FORMULE_IMAGE', type: 'string', length: 200, nullable: true)]
    private ?string $formuleImage = null;

    #[ORM\Column(name: 'INFLAMMABILITE', type: 'string', length: 100, nullable: true)]
    private ?string $inflammabilite = null;

    #[ORM\Column(name: 'SEUIL_ODEUR', type: 'string', length: 100, nullable: true)]
    private ?string $seuilOdeur = null;

    #[ORM\Column(name: 'SUBST_COMBUSTION', type: 'string', length: 100, nullable: true)]
    private ?string $substCombustion = null;

    #[ORM\Column(name: 'LIMITE_SUP_INFLA', type: 'string', length: 100, nullable: true)]
    private ?string $limiteSupInfla = null;

    #[ORM\Column(name: 'LIMITE_INF_INFLA', type: 'string', length: 100, nullable: true)]
    private ?string $limiteInfInfla = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdPhysicoChimiques(): ?int
    {
        return $this->idPhysicoChimiques;
    }

    public function getMasseMolaire(): ?string
    {
        return $this->masseMolaire;
    }

    public function setMasseMolaire(?string $masseMolaire): self
    {
        $this->masseMolaire = $masseMolaire;

        return $this;
    }

    public function getTemperatureEbullition(): ?string
    {
        return $this->temperatureEbullition;
    }

    public function setTemperatureEbullition(?string $temperatureEbullition): self
    {
        $this->temperatureEbullition = $temperatureEbullition;

        return $this;
    }

    public function getTemperatureFusion(): ?string
    {
        return $this->temperatureFusion;
    }

    public function setTemperatureFusion(?string $temperatureFusion): self
    {
        $this->temperatureFusion = $temperatureFusion;

        return $this;
    }

    public function getTemperatureAutoinflammation(): ?string
    {
        return $this->temperatureAutoinflammation;
    }

    public function setTemperatureAutoinflammation(?string $temperatureAutoinflammation): self
    {
        $this->temperatureAutoinflammation = $temperatureAutoinflammation;

        return $this;
    }

    public function getEtatPhysique(): ?string
    {
        return $this->etatPhysique;
    }

    public function setEtatPhysique(?string $etatPhysique): self
    {
        $this->etatPhysique = $etatPhysique;

        return $this;
    }

    public function getForme(): ?string
    {
        return $this->forme;
    }

    public function setForme(?string $forme): self
    {
        $this->forme = $forme;

        return $this;
    }

    public function getCouleur(): ?string
    {
        return $this->couleur;
    }

    public function setCouleur(?string $couleur): self
    {
        $this->couleur = $couleur;

        return $this;
    }

    public function getOdeur(): ?string
    {
        return $this->odeur;
    }

    public function setOdeur(?string $odeur): self
    {
        $this->odeur = $odeur;

        return $this;
    }

    public function getPh(): ?string
    {
        return $this->ph;
    }

    public function setPh(?string $ph): self
    {
        $this->ph = $ph;

        return $this;
    }

    public function getPointEclair(): ?string
    {
        return $this->pointEclair;
    }

    public function setPointEclair(?string $pointEclair): self
    {
        $this->pointEclair = $pointEclair;

        return $this;
    }

    public function getDensiteLiquide(): ?string
    {
        return $this->densiteLiquide;
    }

    public function setDensiteLiquide(?string $densiteLiquide): self
    {
        $this->densiteLiquide = $densiteLiquide;

        return $this;
    }

    public function getDensiteSolide(): ?string
    {
        return $this->densiteSolide;
    }

    public function setDensiteSolide(?string $densiteSolide): self
    {
        $this->densiteSolide = $densiteSolide;

        return $this;
    }

    public function getDensiteVapeur(): ?string
    {
        return $this->densiteVapeur;
    }

    public function setDensiteVapeur(?string $densiteVapeur): self
    {
        $this->densiteVapeur = $densiteVapeur;

        return $this;
    }

    public function getTensionVapeur(): ?string
    {
        return $this->tensionVapeur;
    }

    public function setTensionVapeur(?string $tensionVapeur): self
    {
        $this->tensionVapeur = $tensionVapeur;

        return $this;
    }

    public function getSolubiliteEau(): ?string
    {
        return $this->solubiliteEau;
    }

    public function setSolubiliteEau(?string $solubiliteEau): self
    {
        $this->solubiliteEau = $solubiliteEau;

        return $this;
    }

    public function getCaracteristiquesExplosivite(): ?string
    {
        return $this->caracteristiquesExplosivite;
    }

    public function setCaracteristiquesExplosivite(?string $caracteristiquesExplosivite): self
    {
        $this->caracteristiquesExplosivite = $caracteristiquesExplosivite;

        return $this;
    }

    public function getRemarque(): ?string
    {
        return $this->remarque;
    }

    public function setRemarque(?string $remarque): self
    {
        $this->remarque = $remarque;

        return $this;
    }

    public function getFormuleBrute(): ?string
    {
        return $this->formuleBrute;
    }

    public function setFormuleBrute(?string $formuleBrute): self
    {
        $this->formuleBrute = $formuleBrute;

        return $this;
    }

    public function getFormuleImage(): ?string
    {
        return $this->formuleImage;
    }

    public function setFormuleImage(?string $formuleImage): self
    {
        $this->formuleImage = $formuleImage;

        return $this;
    }

    public function getInflammabilite(): ?string
    {
        return $this->inflammabilite;
    }

    public function setInflammabilite(?string $inflammabilite): self
    {
        $this->inflammabilite = $inflammabilite;

        return $this;
    }

    public function getSeuilOdeur(): ?string
    {
        return $this->seuilOdeur;
    }

    public function setSeuilOdeur(?string $seuilOdeur): self
    {
        $this->seuilOdeur = $seuilOdeur;

        return $this;
    }

    public function getSubstCombustion(): ?string
    {
        return $this->substCombustion;
    }

    public function setSubstCombustion(?string $substCombustion): self
    {
        $this->substCombustion = $substCombustion;

        return $this;
    }

    public function getLimiteSupInfla(): ?string
    {
        return $this->limiteSupInfla;
    }

    public function setLimiteSupInfla(?string $limiteSupInfla): self
    {
        $this->limiteSupInfla = $limiteSupInfla;

        return $this;
    }

    public function getLimiteInfInfla(): ?string
    {
        return $this->limiteInfInfla;
    }

    public function setLimiteInfInfla(?string $limiteInfInfla): self
    {
        $this->limiteInfInfla = $limiteInfInfla;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
