<?php

namespace App\Entity;

use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

/**
 * LutteContreLincendie
 */
#[ORM\Table(name: 'lutte_contre_lincendie')]
#[ORM\Index(name: 'lutte_contre_lincendie_fk1', columns: ['ID_PRODUIT'])]
#[ORM\Entity]
class LutteContreLincendie
{
    #[ORM\Column(name: 'ID_LUTTE_INCENDIE', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $idLutteIncendie;

    #[ORM\Column(name: 'AGENTS_EXTINCTIONS_PRECONISES', type: 'text', length: 0, nullable: true)]
    private ?string $agentsExtinctionsPreconises = null;

    #[ORM\Column(name: 'MOYENS_EXTINCTION_A_EVITER', type: 'text', length: 0, nullable: true)]
    private ?string $moyensExtinctionAEviter = null;

    #[ORM\Column(name: 'EQTS_SPECIAUX_INTERVENANTS', type: 'text', length: 0, nullable: true)]
    private ?string $eqtsSpeciauxIntervenants = null;

    #[ORM\Column(name: 'RISQUES_PARTICULIERS', type: 'text', length: 0, nullable: true)]
    private ?string $risquesParticuliers = null;

    #[ORM\Column(name: 'EXPLOSION', type: 'text', length: 0, nullable: true)]
    private ?string $explosion = null;

    #[ORM\Column(name: 'TOXICITE', type: 'text', length: 0, nullable: true)]
    private ?string $toxicite = null;

    #[ORM\Column(name: 'PRECONISES_CASE', type: 'string', length: 200, nullable: true)]
    private ?string $preconisesCase = null;

    #[ORM\Column(name: 'A_EVITER_CASES', type: 'string', length: 200, nullable: true)]
    private ?string $aEviterCases = null;

    #[ORM\JoinColumn(name: 'ID_PRODUIT', referencedColumnName: 'ID_PRODUIT')]
    #[ORM\ManyToOne(targetEntity: 'Produit')]
    private readonly \App\Entity\Produit $idProduit;

    public function getIdLutteIncendie(): ?int
    {
        return $this->idLutteIncendie;
    }

    public function getAgentsExtinctionsPreconises(): ?string
    {
        return $this->agentsExtinctionsPreconises;
    }

    public function setAgentsExtinctionsPreconises(?string $agentsExtinctionsPreconises): self
    {
        $this->agentsExtinctionsPreconises = $agentsExtinctionsPreconises;

        return $this;
    }

    public function getMoyensExtinctionAEviter(): ?string
    {
        return $this->moyensExtinctionAEviter;
    }

    public function setMoyensExtinctionAEviter(?string $moyensExtinctionAEviter): self
    {
        $this->moyensExtinctionAEviter = $moyensExtinctionAEviter;

        return $this;
    }

    public function getEqtsSpeciauxIntervenants(): ?string
    {
        return $this->eqtsSpeciauxIntervenants;
    }

    public function setEqtsSpeciauxIntervenants(?string $eqtsSpeciauxIntervenants): self
    {
        $this->eqtsSpeciauxIntervenants = $eqtsSpeciauxIntervenants;

        return $this;
    }

    public function getRisquesParticuliers(): ?string
    {
        return $this->risquesParticuliers;
    }

    public function setRisquesParticuliers(?string $risquesParticuliers): self
    {
        $this->risquesParticuliers = $risquesParticuliers;

        return $this;
    }

    public function getExplosion(): ?string
    {
        return $this->explosion;
    }

    public function setExplosion(?string $explosion): self
    {
        $this->explosion = $explosion;

        return $this;
    }

    public function getToxicite(): ?string
    {
        return $this->toxicite;
    }

    public function setToxicite(?string $toxicite): self
    {
        $this->toxicite = $toxicite;

        return $this;
    }

    public function getPreconisesCase(): ?string
    {
        return $this->preconisesCase;
    }

    public function setPreconisesCase(?string $preconisesCase): self
    {
        $this->preconisesCase = $preconisesCase;

        return $this;
    }

    public function getAEviterCases(): ?string
    {
        return $this->aEviterCases;
    }

    public function setAEviterCases(?string $aEviterCases): self
    {
        $this->aEviterCases = $aEviterCases;

        return $this;
    }

    public function getIdProduit(): ?Produit
    {
        return $this->idProduit;
    }

    public function setIdProduit(?Produit $idProduit): self
    {
        $this->idProduit = $idProduit;

        return $this;
    }


}
