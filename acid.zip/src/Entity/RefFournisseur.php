<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * RefFournisseurs
 */
#[ORM\Table(name: 'ref_fournisseurs')]
#[ORM\Entity]
class RefFournisseur
{
    #[ORM\Column(name: 'ID', type: 'integer', nullable: false)]
    #[ORM\Id]
    #[ORM\GeneratedValue(strategy: 'IDENTITY')]
    private readonly int $id;

    #[ORM\Column(name: 'NOM', type: 'string', length: 200, nullable: true)]
    private ?string $nom = null;

    #[ORM\Column(name: 'ADRESSE', type: 'string', length: 200, nullable: true)]
    private ?string $adresse = null;

    #[ORM\Column(name: 'CONTACTS', type: 'string', length: 200, nullable: true)]
    private ?string $contacts = null;

    #[ORM\Column(name: 'TEL', type: 'string', length: 200, nullable: true)]
    private ?string $tel = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(?string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(?string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getContacts(): ?string
    {
        return $this->contacts;
    }

    public function setContacts(?string $contacts): self
    {
        $this->contacts = $contacts;

        return $this;
    }

    public function getTel(): ?string
    {
        return $this->tel;
    }

    public function setTel(?string $tel): self
    {
        $this->tel = $tel;

        return $this;
    }
}
