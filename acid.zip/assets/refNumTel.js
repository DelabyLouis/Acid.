import Routing from '../vendor/friendsofsymfony/jsrouting-bundle/Resources/public/js/router.min.js';

import defaultAjaxOptions from './default_ajax_options';

const routes = require('../public/js/fos_js_routes.json');
Routing.setRoutingData(routes);

$(document).on('click', '#btn_modifier_refNumTel_modal_show', function () {
    $('#formModalLabel').html("<i class='fas fa-lg fa-pencil-alt'></i> " + $(this).data('title'));
    $("#formModalBody").load(Routing.generate('refNumTel_modal_edit', { 'id': $(this).data('id') }));
});