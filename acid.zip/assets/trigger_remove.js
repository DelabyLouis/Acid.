import defaultAjaxOptions from './default_ajax_options'

// Modal de confirmation de suppression
$(document).on('submit', 'form[data-confirmation]', function (event) {
    let $form = $(this),
        $confirm = $('#confirmationModal');

    if ($confirm.data('result') !== 'yes') {
        //cancel submit event
        event.preventDefault();

        $confirm
            .off('click', '#btnYes')
            .on('click', '#btnYes', function () {
                $confirm.data('result', 'yes');
                $form.find('input[type="submit"]').attr('disabled', 'disabled');
                $form.submit();
            })
            .modal('show');
    }
});

// Modal de confirmation de suppression en AJAX
$(document).on('submit', 'form[data-ajaxconfirmation]', function (event) {
    let $form = $(this),
        $confirm = $('#confirmationModal');

    if ($confirm.data('result') !== 'yes') {
        event.preventDefault();

        $confirm
            .off('click', '#btnYes')
            .on('click', '#btnYes', function () {
                //$confirm.data('result', 'yes');
                $form.find('input[type="submit"]').attr('disabled', 'disabled');

                // Suppression via AJAX
                $.ajax($.extend({
                    url: $form.attr('action'),
                    type: 'DELETE',
                    data : $form.serialize(),
                    success: function(data) {
                        $('#formModalLabel').html('');
                        $('#formModalBody').html('');
                        $('#formModal').modal('hide');

                        if (data == 'ok') {
                            $.ajax($.extend({
                                url: $form.data('callback'),
                                type: 'POST',
                                success: function (data) {
                                    $("#" + $form.data('list')).html(data);
                                }
                            }, defaultAjaxOptions()));
                        } else {
                            alert(data);
                        }
                    }
                }, defaultAjaxOptions()));
            })
            .modal('show');
    }
});
