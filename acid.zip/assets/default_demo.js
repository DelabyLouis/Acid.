$('#commune').on('typeahead:selected', function (object, data) {
    $('#commune_code').val(data.code);
    $('#commune_sel').html('Code INSEE : ' + data.code + ' ; Département : ' + data.codeDepartement);
});

$('#adresse').on('typeahead:selected', function (object, data) {
    $('#adresse_sel').html('Label : ' + data.label + ' ; Context : ' + data.context);
});
