import defaultAjaxOptions from "./default_ajax_options";

const routes = require('../public/js/fos_js_routes.json');
import Routing from '../vendor/friendsofsymfony/jsrouting-bundle/Resources/public/js/router.min.js';
Routing.setRoutingData(routes);

$(document).on('typeahead:selected', '#utilisateur_ad_adUser', function (object, data) {
    $('#utilisateur_ad_adUserHidden').val(data.login);
});

// MAJ du select direction en fonction du pôle
$(document).on('change', '#utilisateur_pole', function () {
    let utilisateur_id = $('#utilisateur_id').val() != '' ? $('#utilisateur_id').val() : 0;

    $.ajax($.extend({
        url : Routing.generate('direction_select', {'pole_id': $('#utilisateur_pole').val(), 'utilisateur_id': utilisateur_id}),
        type: 'GET',
        success: function(data) {
            $('#utilisateur_direction').html(data);
        }
    }, defaultAjaxOptions()));
});
