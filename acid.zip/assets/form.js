import defaultAjaxOptions from './default_ajax_options'

// Select2
require('select2');
require('select2/dist/js/i18n/fr');
require('select2/dist/css/select2.css');
require('select2-bootstrap-5-theme/dist/select2-bootstrap-5-theme.css');
require('./styles/select2.css');

$('.select2').select2({
    theme: "bootstrap-5",
    language: "fr",
    width: "100%"
});


// Initialisation des var et chargement du modal pour formulaire AJAX
$("#formModal").on("show.bs.modal", function(e) {
    let title = $(e.relatedTarget).attr("data-title");
    let href = $(e.relatedTarget).attr("data-href");
    let size = $(e.relatedTarget).attr("data-size");

    if (size == 'xl') {
        $(this).find('.modal-dialog').removeClass("modal-lg");
        $(this).find('.modal-dialog').addClass("modal-xl");
    } else {
        $(this).find('.modal-dialog').removeClass("modal-xl");
        $(this).find('.modal-dialog').addClass("modal-lg");
    }

    if (title && href) {
        $("#formModalBody").load(href, function(response, status, xhr) {
            if (xhr.status === 403) {
                window.location.reload();
            }
        });

        $('#formModalLabel').html("<i class='fas fa-pencil-alt'></i> " + title);
    }
});

// Déclenchement des requêtes AJAX de soumission de formulaires modal (hors fichiers)
$(document).on('submit', 'form[data-async]', function (event) {
    let $form = $(this);

    $.ajax($.extend({
        url: $form.attr('action'),
        data: $form.serialize(),
        method: $form.attr('method'),
        success: function (data) {
            if (data == 'ok') {
                $('#formModalLabel').html('');
                $('#formModalBody').html('');
                $('#formModal').modal('hide');

                // Raffraîchissement AJAX
                if ($form.data('callback')) {
                    $.ajax($.extend({
                        url: $form.data('callback'),
                        type: 'POST',
                        success: function (data) {
                            $("#" + $form.data('list')).html(data);
                        }
                    }, defaultAjaxOptions()));
                }

                if ($form.data('callback2')) {
                    $.ajax($.extend({
                        url: $form.data('callback2'),
                        type: 'POST',
                        success: function (data) {
                            $("#" + $form.data('list2')).html(data);
                        }
                    }, defaultAjaxOptions()));
                }
                // Ou redirection de la page entière
            } else if (data.substr(0, 8) == 'redirect') {
                window.location.assign(data.substr(9));
            } else {
                $('#formModalBody').html(data);
            }
        }
    }, defaultAjaxOptions()));

    event.preventDefault();
});
